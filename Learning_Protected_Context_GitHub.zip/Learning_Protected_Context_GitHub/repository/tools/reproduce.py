"""Convenience commands around the preserved, original research code."""
from pathlib import Path
import argparse
import json
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
SCOPE=json.loads((ROOT/'provenance/PACKAGE_SCOPE.json').read_text())
LARGE=SCOPE['large_results_in_separate_release_assets']
OUT=ROOT/'reproduced'

def run(args,cwd,log):
    log.parent.mkdir(parents=True,exist_ok=True)
    print('Running:', ' '.join(map(str,args)),flush=True)
    with log.open('w',encoding='utf-8') as stream:
        result=subprocess.run(list(map(str,args)),cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
    print(log.read_text(encoding='utf-8',errors='replace')[-8000 if result.returncode else -1200:])
    if result.returncode:
        raise SystemExit(f'Command failed ({result.returncode}); see {log}')

def main():
    choices=['test','audit','paper']+([] if LARGE else ['figures','smoke','development'])
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('command',choices=choices)
    args=ap.parse_args();OUT.mkdir(exist_ok=True)
    if args.command=='paper':
        if not shutil.which('pdflatex'):
            raise SystemExit('Install pdfLaTeX/TeX Live first, or import manuscript/ into Overleaf.')
        dest=OUT/'manuscript';shutil.copytree(ROOT/'manuscript',dest,dirs_exist_ok=True)
        for i in (1,2):
            run(['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],dest,OUT/f'paper-build-{i}.log')
        print('Compiled PDF:',dest/'main.pdf')
        print('Expected page count:',SCOPE['formatted_pages'])
    elif args.command=='audit':
        if LARGE:
            study=ROOT/'results/core_study'
            if not (study/'EVALUATION_OPENED.json').exists():
                raise SystemExit('Restore the four release assets first: python tools/restore_results.py')
            dest=OUT/'evidence';dest.mkdir(exist_ok=True)
            run([sys.executable,ROOT/'experiment/build_paper_evidence.py',study,dest],ROOT,OUT/'audit.log')
        else:
            run([sys.executable,ROOT/'evidence_audit/audit_evidence.py','--evidence',ROOT/'evidence_audit/evidence','--out',OUT/'audit'],ROOT,OUT/'audit.log')
    elif args.command=='test':
        if LARGE:
            with tempfile.TemporaryDirectory(prefix='dpcast-protocol-') as temporary:
                code=Path(temporary)/'experiment';shutil.copytree(ROOT/'experiment',code)
                run([sys.executable,'verify_protocol.py'],code,OUT/'protocol-tests.log')
                shutil.copyfile(code/'integration_checks.json',OUT/'integration_checks.json')
        else:
            run([sys.executable,'-m','unittest','-v','test_correctness'],ROOT/'code/earlier',OUT/'earlier-tests.log')
            run([sys.executable,'-m','unittest','discover','-s','tests','-v'],ROOT/'code/revised',OUT/'revised-tests.log')
    elif args.command=='figures':
        work=OUT/'figure_work';work.mkdir(exist_ok=True)
        shutil.copyfile(ROOT/'evidence_audit/make_figures.py',work/'make_figures.py')
        shutil.copytree(ROOT/'evidence_audit/evidence',work/'evidence',dirs_exist_ok=True)
        run([sys.executable,'make_figures.py'],work,OUT/'figures.log')
        shutil.copytree(work/'paper/figures',OUT/'figures',dirs_exist_ok=True)
        print('Regenerated figures:',OUT/'figures')
    elif args.command=='smoke':
        code=ROOT/'code/revised';study=OUT/'synthetic_study'
        for phase in ['prepare','train','evaluate','audit','analyze']:
            cmd=[sys.executable,code/'run.py',phase,'--out',study]
            if phase=='prepare':cmd+=['--config',ROOT/'configs/reported_synthetic.json']
            run(cmd,code,OUT/f'smoke-{phase}.log')
    elif args.command=='development':
        code=ROOT/'code/earlier';study=OUT/'cervical_development'
        for phase in ['train','analyze']:
            run([sys.executable,code/'run.py',phase,'--config',ROOT/'configs/reported_cervical.json','--out',study,'--cache',OUT/'dataset-cache'],code,OUT/f'development-{phase}.log')

if __name__=='__main__':main()
