"""Verify and restore the four original v5 result ZIPs; no downloads or training."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import shutil
import stat
import zipfile

ROOT=Path(__file__).resolve().parents[1]

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def member_path(name):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name:
        raise ValueError('Unsafe archive path: '+name)
    return p

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--assets',type=Path,default=ROOT.parent/'release-assets')
    ap.add_argument('--out',type=Path,default=ROOT/'results')
    args=ap.parse_args();assets=args.assets.resolve();out=args.out.resolve()
    manifest=json.loads((ROOT/'provenance/release_assets.json').read_text())
    for info in manifest['assets']:
        f=assets/info['filename']
        if not f.is_file():raise SystemExit(f'Missing {f}. Download all four ZIP assets from the repository release.')
        if f.stat().st_size!=info['bytes'] or digest(f)!=info['sha256']:
            raise SystemExit('Asset checksum mismatch: '+str(f))
        print('Verified asset:',f.name,flush=True)
    out.mkdir(parents=True,exist_ok=True)
    seen=set()
    for info in manifest['assets']:
        with zipfile.ZipFile(assets/info['filename']) as archive:
            for item in archive.infolist():
                name=member_path(item.filename)
                if stat.S_ISLNK(item.external_attr>>16):raise SystemExit('Symlink in result archive: '+item.filename)
                if item.is_dir():continue
                if item.filename in seen:raise SystemExit('Duplicate member across result archives: '+item.filename)
                seen.add(item.filename)
                target=out.joinpath(*name.parts)
                if target.resolve()!=target.absolute():raise SystemExit('Destination passes through a symlink: '+str(target))
                target.parent.mkdir(parents=True,exist_ok=True)
                if target.exists():
                    # Do not overwrite evidence that a user may have edited.
                    with archive.open(item) as src:
                        h=hashlib.sha256()
                        for block in iter(lambda:src.read(1024*1024),b''):h.update(block)
                    if digest(target)!=h.hexdigest():raise SystemExit('Existing file differs; use a fresh --out folder: '+str(target))
                else:
                    temp=target.with_name(target.name+'.extracting')
                    with archive.open(item) as src,temp.open('wb') as dst:shutil.copyfileobj(src,dst)
                    temp.replace(target)
        print('Restored:',info['filename'],flush=True)
    recorded=json.loads((out/'ARCHIVE_MANIFEST.json').read_text())
    for name,expected in recorded['files'].items():
        rel=member_path(name);p=out.joinpath(*rel.parts)
        if not p.is_file() or p.stat().st_size!=expected['bytes'] or digest(p)!=expected['sha256']:
            raise SystemExit('Original archive-manifest mismatch: '+name)
    print('Verified original result-manifest files:',len(recorded['files']),flush=True)
    cache=out/'core_study/public_sources'
    mapping={p.stem:str(p.resolve()) for p in sorted(cache.glob('*.csv'))}
    if len(mapping)!=4:raise SystemExit('Expected four original public input CSV files.')
    regenerated=ROOT/'reproduced';regenerated.mkdir(exist_ok=True)
    (regenerated/'local_sources.json').write_text(json.dumps(mapping,indent=2)+'\n')
    print('Saved original-input path mapping:',regenerated/'local_sources.json')
    if out!=ROOT/'results':print('Custom output selected. Pass its core_study path directly to experiment/build_paper_evidence.py.')

if __name__=='__main__':main()
