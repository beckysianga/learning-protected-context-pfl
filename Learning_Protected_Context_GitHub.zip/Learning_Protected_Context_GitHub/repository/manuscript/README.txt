OVERLEAF PROJECT
Learning to Acquire Protected Context for Personalized Federated Learning

This project contains the source of the formatted eight-page IEEE paper.

UPLOAD AND COMPILE
1. In Overleaf, choose New Project, then Upload Project.
2. Select the ZIP file. You do not need to unzip it first.
3. Set the main document to main.tex and the compiler to pdfLaTeX.
4. Click Recompile. Download the generated PDF when compilation finishes.

FILES
main.tex                 Complete manuscript, equations and editable tables.
references.tex           All 27 references in a LaTeX thebibliography environment.
figure1.pdf              Original vector figure: paired gate-learning results.
figure2.pdf              Original vector figure: histogram evaluation error.
IEEEtran.cls             Unmodified IEEE conference class, version 1.8b.
compiled/IEEE_8_Page_Paper.pdf  Previously verified eight-page PDF for comparison.
README.txt               These instructions.

The bibliography is included with \input{references.tex}; no .bib or .bst file,
BibTeX, or Biber is required. All manuscript asset paths are relative.
Standard LaTeX packages used by the project are supplied by Overleaf.
The class retains its original copyright and LaTeX Project Public License notices.

LAYOUT AND VERIFICATION
IEEE conference mode; US Letter (8.5 x 11 inches); two columns; 10-point body.
The project uses the IEEE class sizes for the title, abstract, tables and references.
A clean local build with pdfLaTeX (TeX Live 2023) produces eight pages.
All 11 tables, both figures, 12 numbered equations and 27 references are included.
This is the paper compilation project; experiment data and research-code archives
are not needed to compile it and are not included.

LOCAL COMPILATION (optional)
Run: latexmk -pdf main.tex
Or run: pdflatex main.tex twice to resolve citations and cross-references.

SUBMISSION NOTE
The quoted conference instructions conflict: 6-8 pages versus a maximum of two.
This project implements the eight-page full-paper interpretation. Confirm the
applicable limit with the organisers before submitting the resulting PDF to EDAS.
Overleaf compilation and EDAS submission are separate steps.

Overleaf upload documentation:
https://docs.overleaf.com/managing-projects-and-files/uploading-a-project
