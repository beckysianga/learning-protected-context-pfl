# Reproducing the acquisition paper

## 1. Restore and verify saved evidence

From the repository root, after installing requirements:

```text
python tools/verify_checksums.py
python tools/restore_results.py
python tools/reproduce.py audit
```

`restore_results.py` checks all four asset SHA-256 values before extraction,
rejects unsafe archive paths, and verifies every file in the original archive
manifest. It writes under `results/`. Do not concatenate the ZIP parts.

The evidence builder reads `results/core_study/` and writes
`reproduced/evidence/derived_v5/`, `tables/`, and `figures/`. It never trains or
selects a model. Compare the regenerated CSVs and audit report with `evidence/`
and `validation/packaging_artifact_audit.json`. Histogram draws describe
estimator noise conditional on saved models, not independent training seeds.

## 2. Validate the implementation and compile the paper

```text
python tools/reproduce.py test
python tools/reproduce.py paper
```

The test command runs the original protocol integration checks in a temporary
copy, preserving the archived validation record. It checks resumption and the
test-opening barrier using small synthetic cases. The paper command compiles
the current source twice in `reproduced/manuscript/`, with an expected eight
pages. The bibliography is embedded in `references.tex`; BibTeX is unnecessary.

## 3. Retrain separately, if needed

This is optional, substantially more expensive than auditing saved outputs,
and was not done during packaging. Use the pinned environment and new output
directories. Restored public CSVs let the original code validate original
source hashes without redownloading the data.

```text
python experiment/run_parallel.py --stage development --root reproduced/new-development --workers 4 --local-sources reproduced/local_sources.json
python experiment/run_parallel.py --stage final --root reproduced/new-core-study --workers 4 --local-sources reproduced/local_sources.json
```

The first command plans 56 development runs; the second plans 560 final runs.
Both orchestrators may run for a long time. Keep the entire output directory
to resume with the same command, source, and environment. Do not run two
orchestrators against the same directory. Do not change or remove a protocol
lock to bypass an identity mismatch. Core final seeds are 142 through 232
in steps of ten; development uses 42. The extended profile is unexecuted
prospective work and is not evidence for the paper.

For Colab/Jupyter, use `experiment/DP_CAST_v5_SingleCell.ipynb`; the original
operational settings default to development. Read
`provenance/ORIGINAL_V5_README.txt` for phase selection and persistent storage.

## Scope and provenance

The original study and this audit use Python 3.12.14 with the numerical versions
recorded in `experiment/environment-tested.json` and `requirements.txt`.
Recorded hashes and exact saved predictions are the authoritative evidence.
Bitwise retraining is not promised across BLAS, operating systems, or versions.
The saved protocol commits 560 models before opening final test scoring.
Earlier benchmark exposure remains a limitation despite a new fixed holdout.
These are simulations on public benchmarks, not independent hospital trials.

The original source archive used an earlier title variant, "Learning When to
Acquire Protected Context for Personalized Federated Learning". The current
manuscript uses "Learning to Acquire..." and the same v5 evidence. No results
from the separate sparse-feedback paper have been inserted.
