# Learning to Acquire Protected Context for Personalized Federated Learning

Reproducibility package for the formatted **eight-page** manuscript.
Suggested GitHub repository name: `learning-protected-context-pfl`.

## Evidence provided

This is the v5 study: **560 final runs**, four datasets, 14 methods, and ten
seeds (142, 152, ..., 232), with 60 rounds, Dirichlet alpha 0.5, and epsilon 16
at delta 1e-5. A separate 56-run development study is retained. Do not combine
these results with the sparse-feedback paper's 13 runs.

`experiment/` contains the original standalone implementation, single-cell
notebook, protocol checks, parallel launcher, and evidence builder.
`evidence/` provides small, reviewable analysis tables, feature audits, and
protocol records. `provenance/` retains the original source archive.

All raw results are supplied as **four separate release-asset downloads**
(about 1.1 GB compressed, about 1.67 GB expanded). Download all four and place
them in a `release-assets/` folder beside `repository/` in the extracted package.
They contain public input CSVs, partitions, source snapshots, checkpoints,
models, predictions, logs, accounting ledgers, and histogram draws. These files
belong in a GitHub Release, not in ordinary Git commits. They are all required
for a complete saved-output reconstruction. The small repository alone does not
contain those complete raw results.

Before the audit command below, restore the assets from the four separate downloads
or a published GitHub Release:

```text
python tools/restore_results.py
```

For assets saved elsewhere, use `python tools/restore_results.py --assets PATH`.
This verifies archive checksums and the original manifest and restores the
disjoint files under `results/`. The command also writes
`reproduced/local_sources.json` for an offline retraining attempt.

Packaging re-ran the original audit: **7,040 committed file hashes** and
**38,080 metric values** passed across 4,480 head prediction vectors; the maximum
finite discrepancy was 3.89e-16. The audit also checked the 560-model evaluation
gate, paired initialization, schedules, seed coverage, and fixed holdouts.

The primary gate-learning comparisons remain inconclusive; all four adjusted
primary p-values are 1.00. Do not describe successful execution as a demonstrated
predictive benefit or equivalence.


## Repository contents

`manuscript/` contains the formatted LaTeX paper, bibliography, vector figures,
IEEE template, and the verified PDF. `requirements.txt` records the numerical
versions used for audit validation. `tools/` provides convenient entry points;
`validation/` records checks run when this package was assembled. `CITATION.cff`
contains author metadata. `GITHUB_UPLOAD.md` explains publication.

Install the numerical tools in an isolated environment (Python 3.12 is the
audit environment used during packaging):

```text
python -m venv .venv
```

Activate on Windows PowerShell with `.\.venv\Scripts\Activate.ps1`, or on
macOS/Linux with `source .venv/bin/activate`, then run:

```text
python -m pip install -r requirements.txt
python tools/verify_checksums.py
```

The tests and audits run on CPU. A GPU is not required. LaTeX compilation
separately requires pdfLaTeX/TeX Live (locally verified with TeX Live 2023).

```text
python tools/reproduce.py test
python tools/reproduce.py audit
python tools/reproduce.py paper
```

New outputs go into `reproduced/`, which is excluded from Git. Original evidence
and locked source files remain unchanged. The archived readme/configuration files
retain their historical wording; this top-level README defines the evidence
scope of the present manuscript. No new scientific training study was executed
to assemble this package. Integration tests may run small temporary simulations.

The repositories contain public-benchmark diagnostics. Seeded randomness,
exact labels, scores, and diagnostic archives are outside the papers' ideal
confidential-release boundaries. Passing numerical audits does not certify
privacy, security, external validity, or clinical effectiveness.

Read `REPRODUCIBILITY.md` for the detailed commands and limits.
