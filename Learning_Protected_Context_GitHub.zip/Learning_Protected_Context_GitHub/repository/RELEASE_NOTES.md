# Reproducibility package v1.0.0

Eight-page manuscript, original v5 implementation/notebook, numerical
requirements, protocol records, feature audits, analysis tables, and
reproduction tools. The four attached ZIP assets jointly contain all 560 final
and 56 development runs and public data inputs. Download all four; extract
together with the checksum-verifying tool. Saved-output audit: 7,040 committed
hashes and 38,080 metric entries verified. No new full training study was run
during packaging. The results do not establish a gate-learning utility benefit.
