"""Run all planned jobs, then open the locked evaluation once; public data only.

python run_parallel.py --stage development --root /path/development --workers 4
python run_parallel.py --stage final --root /path/study --workers 4
Use different roots. Workers write disjoint run folders. Interrupted jobs resume.
"""
import argparse
import importlib.util
import os
from pathlib import Path
import subprocess
import sys


def load():
    path=Path(__file__).with_name('DP_CAST_v5_SingleCell.py')
    spec=importlib.util.spec_from_file_location('dpcast_v5',path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    return module


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stage',choices=['development','final'],required=True)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--worker',action='store_true')
    parser.add_argument('--local-sources',type=Path)
    args=parser.parse_args()
    if args.workers<1:parser.error('workers must be positive')
    os.environ['DPCAST_DOWNLOAD']='0'
    if args.local_sources:os.environ['DPCAST_LOCAL_CSV']=args.local_sources.read_text()
    root=args.root.resolve();development=args.stage=='development'
    m=load()
    if args.worker:
        lock=m.verify_lock(root,development)
        m.train_study(root,lock)
        return
    report=m.self_tests();lock=m.lock_study(root,development)
    m.write_json(root/'self_tests.json',report)
    logs=root/'worker_logs';logs.mkdir(exist_ok=True)
    processes=[];streams=[]
    for index in range(args.workers):
        env=os.environ.copy();env.update(DPCAST_SHARDS=str(args.workers),DPCAST_SHARD_INDEX=str(index))
        stream=(logs/f'worker_{index}.log').open('a');streams.append(stream)
        command=[sys.executable,str(Path(__file__).resolve()),'--stage',args.stage,'--root',str(root),'--workers',str(args.workers),'--worker']
        processes.append(subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT))
    # All models must finish before any test predictions. No performance-based filtering.
    codes=[p.wait() for p in processes]
    for stream in streams:stream.close()
    if any(codes):raise RuntimeError(f'Worker failures {codes}; inspect logs and resume the same locked implementation.')
    m.evaluate_study(root,lock,development)
    m.analyse(root,lock,development);m.privacy_report(root,lock)
    print('COMPLETE',root,flush=True)
    # Packaging is an explicit later operation, to avoid duplicate multi-GB archives.


if __name__=='__main__':main()
