"""Package a completed study and editable paper without changing locked results."""
import argparse,hashlib,json,zipfile
from pathlib import Path

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def archive(target,trees,extra=()):
    files=[]
    for root,name in trees:
        for p in sorted(root.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.tmp','.pyc','.aux','.out','.blg'} and p.name!='main.log':
                files.append((p,str(Path(name)/p.relative_to(root))))
    files.extend(extra)
    manifest={name:{'sha256':digest(p),'bytes':p.stat().st_size} for p,name in files}
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as z:
        for p,name in files:z.write(p,name)
        z.writestr('ARCHIVE_MANIFEST.json',json.dumps({'public_benchmark_only':True,'files':manifest},indent=2))
    with zipfile.ZipFile(target) as z:
        bad=z.testzip()
        if bad:raise RuntimeError('ZIP CRC failed: '+bad)
    return {'filename':target.name,'bytes':target.stat().st_size,'sha256':digest(target),'files':len(files)}

def main():
    a=argparse.ArgumentParser();a.add_argument('--source',type=Path,required=True);a.add_argument('--core',type=Path,required=True);a.add_argument('--development',type=Path,required=True);a.add_argument('--output',type=Path,required=True);q=a.parse_args()
    report=json.loads((q.core/'analysis_PUBLIC_ONLY/completeness.json').read_text())
    if report['evaluated']!=560 or report['missing_job_ids']:raise RuntimeError('Cannot package an incomplete core study as completed.')
    results=[]
    results.append(archive(q.output/'DP_CAST_Paper4_v5_Submission_Source.zip',[(q.source,'DP_CAST_Paper4_v5_Submission')]))
    results.append(archive(q.output/'DP_CAST_Paper4_v5_Results.zip',[(q.core,'core_study'),(q.development,'development')],[(q.source/'README.txt','README.txt'),(q.source/'experiment/DEVELOPMENT_REVIEW_BEFORE_FINAL_LOCK.json','DEVELOPMENT_REVIEW_BEFORE_FINAL_LOCK.json')] ))
    (q.output/'DP_CAST_Paper4_v5_Package_Checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2),flush=True)

if __name__=='__main__':main()
