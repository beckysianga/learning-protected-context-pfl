"""Audit completed v5 archives and generate manuscript tables/figures.

Usage: python build_paper_evidence.py CORE_STUDY PAPER_DIRECTORY
This postprocessing script never trains, selects, or changes a model.
"""
import hashlib,json,sys,math
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score,roc_auc_score,brier_score_loss
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(sys.argv[1]); PAPER=Path(sys.argv[2]); OUT=PAPER/'derived_v5'
OUT.mkdir(exist_ok=True); (PAPER/'tables').mkdir(exist_ok=True); (PAPER/'figures').mkdir(exist_ok=True)
DS=['Cervical_Cancer','CDC_Diabetes','Glioma_Grading','SUPPORT2']
DN={'Cervical_Cancer':'Cervical Cancer','CDC_Diabetes':'CDC Diabetes','Glioma_Grading':'Glioma Grading','SUPPORT2':'SUPPORT2'}
METHODS=['non_private','fixed_dp','adaptive_clip','rule','random','frozen','learned','gate_frozen','gate_learned','gate_periodic','gate_random','gate_no_recycle','gate_constant','gate_noise_only']
MN=dict(zip(METHODS,['Non-private','Fixed DP','Adaptive clipping','Rule allocation','Random allocation','Frozen allocation','Learned allocation','Frozen gate','Learned gate','Periodic acquisition','Random acquisition','No recycling','Constant context','Noise-only context']))
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,indent=2,allow_nan=False))
def tex(name,caption,label,columns,header,rows,wide=False,note=''):
    env='table*' if wide else 'table'
    text='\\begin{'+env+'}[t]\n\\caption{'+caption+'}\\label{'+label+'}\n\\centering\\small\n\\begin{tabular}{'+columns+'}\\toprule\n'
    text+=' & '.join(header)+'\\\\\\midrule\n'
    text+='\n'.join(' & '.join(map(str,r))+'\\\\' for r in rows)
    text+='\n\\bottomrule\\end{tabular}\n'
    if note:text+='\\par\\smallskip\\begin{minipage}{'+('0.98\\textwidth' if wide else '\\columnwidth')+'}\\footnotesize '+note+'\\end{minipage}\n'
    text+='\\end{'+env+'}\n';(PAPER/'tables'/name).write_text(text)
def ran(x,dec=0):
    a,b=min(x),max(x)
    return (f'{a:,.{dec}f}' if a==b else f'{a:,.{dec}f}--{b:,.{dec}f}')
def mean_ci(x):
    x=np.asarray(x);m=x.mean();h=stats.t.ppf(.975,len(x)-1)*x.std(ddof=1)/math.sqrt(len(x));return m,m-h,m+h
def metrics(y,p):
    bins=np.minimum((p*10).astype(int),9)
    ece=sum((bins==b).mean()*abs(p[bins==b].mean()-y[bins==b].mean()) for b in range(10) if (bins==b).any())
    return {'ap':average_precision_score(y,p) if y.sum() else np.nan,
            'auroc':roc_auc_score(y,p) if len(np.unique(y))==2 else np.nan,
            'brier':brier_score_loss(y,p),'ece':ece}
lock=read(ROOT/'protocol_lock.json'); gate=read(ROOT/'EVALUATION_OPENED.json')
assert not lock['development'] and gate['protocol_sha256']==lock['protocol_sha256']
assert len(lock['jobs'])==560 and len(gate['models'])==560
assert gate['model_set_sha256']==hashlib.sha256(json.dumps(gate['models'],sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
hash_count=0; metric_count=0; max_error=0.; trains=[]; evaluations=[]; recomputed=[]
for k,job in enumerate(lock['jobs']):
    folder=ROOT/'runs'/job['job_id']
    for marker in ['TRAIN_COMPLETE.json','EVAL_COMPLETE.json']:
        record=read(folder/marker);assert record['protocol_sha256']==lock['protocol_sha256']
        for name,digest in record['files'].items():
            assert sha(folder/name)==digest,(job['job_id'],name);hash_count+=1
    assert sha(folder/'final_model.npz')==gate['models'][job['job_id']]
    tr=read(folder/'training_summary.json');ev=read(folder/'evaluation.json');trains.append(tr);evaluations.append(ev)
    assert ev['evaluation_split']=='test' and not ev['development'] and tr['learning_timing_pass']
    common=pd.read_csv(folder/'common_head_metrics_PUBLIC_ONLY.csv').set_index('client')
    local=pd.read_csv(folder/'local_metrics_PUBLIC_ONLY.csv').set_index('client')
    rec=[]
    with np.load(folder/'predictions_PUBLIC_ONLY.npz',allow_pickle=False) as z:
        y=z['labels'];group=z['client_assignment']
        assert set(np.unique(group))==set(range(8))
        for client in range(8):
            p=z[f'head_{client}'];assert len(p)==len(y) and np.isfinite(p).all()
            for scope,mask,reference in [('common',np.ones(len(y),bool),common),('local',group==client,local)]:
                vals=metrics(y[mask],p[mask]); row=dict(job_id=job['job_id'],dataset=job['dataset'],seed=job['seed'],method=job['method'],client=client,scope=scope,**vals)
                recomputed.append(row)
                for key,value in vals.items():
                    saved=reference.loc[client,key]
                    if np.isnan(value):assert np.isnan(saved)
                    else:
                        err=abs(value-saved);max_error=max(max_error,err);assert err<1e-12,(job,key,err)
                    metric_count+=1
                if scope=='common':rec.append(vals)
        for key in ['ap','auroc','brier','ece']:
            value=np.mean([x[key] for x in rec]);err=abs(value-ev['common_mean_head_'+key]);max_error=max(max_error,err);assert err<1e-12;metric_count+=1
    if job['method']!='non_private':
        costs=pd.read_csv(folder/'final_accounting.csv');assert len(costs)==8 and np.allclose(costs.epsilon,16,atol=1e-10)
    if (k+1)%40==0:print('AUDIT',k+1,'/560',flush=True)
pd.DataFrame(recomputed).to_csv(OUT/'recomputed_head_metrics.csv',index=False)
tr=pd.DataFrame(trains);ev=pd.DataFrame(evaluations)
assert tr.groupby(['dataset','seed'])[['initialisation_hash','schedule_hash','bundle_hash']].nunique().eq(1).all().all()
assert ev.groupby(['dataset','method']).seed.nunique().eq(10).all()
assert ev.groupby(['dataset','seed']).method.nunique().eq(14).all()
inventory=[];support=[];holdout_hashes={}
for dataset in DS:
    metadata=[(bid,v) for bid,v in lock['bundles'].items() if v['dataset']==dataset]
    assert len(metadata)==10
    hashes={v['holdout_indices_sha256'] for _,v in metadata};assert len(hashes)==1;holdout_hashes[dataset]=next(iter(hashes))
    sizes=[];positives=[];test_membership=[]
    for bid,v in metadata:
        folder=ROOT/'bundles'/bid
        with np.load(folder/'split_indices.npz') as z:
            a,b,c=[set(z[x].tolist()) for x in ['train','validation','test']]
            assert not a&b and not a&c and not b&c
            assert len(a|b|c)==v['n'];test_membership.append(c)
        s=pd.read_csv(folder/'support_PUBLIC_ONLY.csv');s['dataset']=dataset;s['seed']=v['seed'];support.append(s)
        sizes.append(v['split_sizes']);positives.append([int(s[s.split==x].positive.sum()) for x in ['training','validation','test']])
    assert all(x==test_membership[0] for x in test_membership)
    v=metadata[0][1];ss=np.array(sizes);pp=np.array(positives)
    inventory.append(dict(dataset=dataset,records=v['n'],positives=v['positive'],inputs=v['features'],train_n=ran(ss[:,0]),validation_n=ran(ss[:,1]),test_n=int(ss[0,2]),test_positive=int(pp[0,2]),train_positive=ran(pp[:,0]),validation_positive=ran(pp[:,1])))
inv=pd.DataFrame(inventory);inv.to_csv(OUT/'dataset_inventory.csv',index=False)
sup=pd.concat(support,ignore_index=True);sup.to_csv(OUT/'all_client_support.csv',index=False)
report=dict(protocol_sha256=lock['protocol_sha256'],runs=560,head_prediction_vectors=4480,verified_artifact_hashes=hash_count,verified_metric_values=metric_count,maximum_metric_absolute_error=max_error,paired_blocks=40,methods_per_block=14,seeds_per_dataset=10,holdout_hashes=holdout_hashes,all_training_complete_before_test_gate=True,all_training_timing_pass=True)
write(OUT/'artifact_audit.json',report)
tex('data.tex','Dataset inventory and fixed test membership','tab:data','lrrrrll',['Dataset','Records','Positives','Inputs','Test ($+$)','Train $n$','Validation $n$'],[[DN[r.dataset],f'{r.records:,}',f'{r.positives:,}',r.inputs,f'{r.test_n:,} ({r.test_positive:,})',r.train_n,r.validation_n] for r in inv.itertuples()],True,'Ranges cover ten seeds. Test membership is identical across seeds. Training and validation positive counts appear in the supplement. Glioma uses the original all-records CSV. Encoded inputs include missingness indicators and hash buckets.')
spec=[['Non-private','None','Fixed','Fixed'],['Fixed DP','None','Fixed','Fixed'],['Adaptive clipping','None','Fixed','Protected statistic'],['Rule allocation','Every visit','Rule','Contextual action'],['Random allocation','Every visit','Random','Contextual action'],['Frozen allocation','Every visit','Initial network','Contextual action'],['Learned allocation','Every visit','Learned','Contextual action'],['Frozen gate','Initial gate','Learned','Contextual action'],['Learned gate','Learned gate','Learned','Contextual action'],['Periodic acquisition','Every second visit','Learned','Contextual action'],['Random acquisition','Probability 0.5','Learned','Contextual action'],['No recycling','Always paid','Learned','Contextual action'],['Constant context','Learned gate; constant vector','Learned','Contextual action'],['Noise-only context','Learned gate; synthetic vector','Learned','Contextual action']]
tex('methods.tex','Main controls and acquisition ablations','tab:methods','llll',['Method','Context acquisition','Allocation','Clipping'],spec,True,'The first nine rows form the main comparison. The final five rows form the acquisition ablations. All gated methods force the first query. No recycling pays for every query but discards fresh context when reuse is selected. All private simulations share the same conservative configured bound.')
summary=ev.groupby(['dataset','method']).agg(ap=('common_mean_head_ap','mean'),sd=('common_mean_head_ap','std'),auroc=('common_mean_head_auroc','mean'),brier=('common_mean_head_brier','mean'),ece=('common_mean_head_ece','mean')).reset_index()
summary.to_csv(OUT/'performance_summary.csv',index=False)
piv=summary.set_index(['dataset','method'])
rows=[[MN[m]]+[f'{piv.loc[(d,m),"ap"]:.4f} $\\pm$ {piv.loc[(d,m),"sd"]:.4f}' for d in DS] for m in METHODS]
rows.append(['Constant-score AP']+[f'{ev[ev.dataset==d].test_prevalence_REFERENCE_ONLY.iloc[0]:.4f}' for d in DS])
tex('performance.tex','Common-test mean head AP across ten seeds','tab:performance','lrrrr',['Method']+[DN[d] for d in DS],rows,True,'Values are mean $\\pm$ sample standard deviation across ten seeds. Each run first averages eight head-specific AP scores on the same test records. Non-private control is outside the matched privacy comparison. The constant-score row equals fixed test prevalence.')
ana=ROOT/'analysis_PUBLIC_ONLY';primary=pd.read_csv(ana/'PRIMARY_paired_dataset_comparisons.csv').set_index('dataset').loc[DS]
tex('primary.tex','Primary paired effect of gate learning','tab:primary','lrrrr',['Dataset','$\\Delta$AP','95\\% paired $t$ CI','Holm $p$','W/T/L'],[[DN[d],f'{r.mean_difference:+.5f}',f'[{r.t_ci_low:+.5f}, {r.t_ci_high:+.5f}]',f'{r.holm_p:.4f}',f'{int(r.wins)}/{int(r.ties)}/{int(r.losses)}'] for d,r in primary.iterrows()],True,'Difference = learned gate minus frozen gate. Both arms train the allocation controller. W/T/L counts the ten seed differences. Holm adjustment covers four primary dataset hypotheses; displayed intervals are pointwise. Exact sign-flip tests rely on symmetric or exchangeable null differences.')
abl=pd.read_csv(ana/'EXPLORATORY_ablation_comparisons.csv');ga=abl[abl.method.str.startswith('gate_')]
ga.to_csv(OUT/'gate_ablation_comparisons.csv',index=False)
tex('ablations.tex','Paired effects of acquisition ablations','tab:ablations','llrrr',['Dataset','Ablation','$\\Delta$AP','95\\% paired $t$ CI','Holm $p$'],[[DN[d],MN[m],f'{r.mean_difference:+.5f}',f'[{r.t_ci_low:+.5f}, {r.t_ci_high:+.5f}]',f'{r.holm_p_exploratory_family:.4f}'] for d in DS for m in METHODS[9:] for _,r in ga[(ga.dataset==d)&(ga.method==m)].iterrows()],True,'Difference = ablation minus learned gate. Positive values favor the ablation. Intervals are pointwise. The locked exploratory adjustment family contains these 20 contrasts and four allocation-learning contrasts at the same context price. These comparisons do not isolate every interaction between gate, allocation, and noise trajectory.')
controller=[]
for d in DS:
    g=tr[(tr.dataset==d)&(tr.method=='gate_learned')];first=list(g.first_gate_update)
    controller.append(dict(dataset=d,first_round=ran([x['round'] for x in first]),first_decision=ran([x['decision'] for x in first]),training_updates=ran(g.gate_training_updates),later_decisions=ran(g.gate_decisions_after_update),gate_changed=ran(g.gate_changed_nonexploratory),allocation_changed=ran(g.changed_executed_nonexploratory),query_mean=g.context_query_rate.mean(),query_min=g.context_query_rate.min(),query_max=g.context_query_rate.max()))
con=pd.DataFrame(controller);con.to_csv(OUT/'controller_summary.csv',index=False)
query=tr.groupby(['dataset','method']).context_query_rate.mean().unstack('dataset')
query.to_csv(OUT/'mean_query_rates.csv')
tex('queries.tex','Mean fraction of client visits with a paid context query','tab:queries','lrrrr',['Method']+[DN[d] for d in DS],[[MN[m]]+[f'{query.loc[m,d]:.3f}' for d in DS] for m in METHODS[6:]],True,'Values average ten seeds. Learned allocation always queries. The no-recycling ablation also pays for every query, even when its gate discards the result. All gated methods force a query at each client\'s first visit. Actual rates need not match between policies.')
tex('controllers.tex','Learned-gate activity across ten seeds','tab:controllers','lrrrrrr',['Dataset','First round','First decision','Updates / later','Gate changes','Alloc. changes','Query rate'],[[DN[r.dataset],r.first_round,r.first_decision,r.training_updates+' / '+r.later_decisions,r.gate_changed,r.allocation_changed,f'{r.query_mean:.3f}'] for r in con.itertuples()],True,'Ranges summarize ten runs. Updates exclude terminal replay; later counts decisions after an update. Query rates are means. Changed actions use identical protected states and compare trained versus initial networks on nonexploratory decisions. Logs retain the exact first-update client, Q-losses, protected feedback, actions, and cumulative costs.')
loc=[]
for d in DS:
    s=sup[(sup.dataset==d)&(sup.split=='test')];e=ev[(ev.dataset==d)&(ev.method=='gate_learned')]
    loc.append(dict(dataset=d,client_n=ran(s.n),positive=ran(s.positive),zero_positive=int((s.positive==0).sum()),client_splits=len(s),ap_defined=ran(e.valid_local_ap_clients),auroc_defined=ran(e.valid_local_auroc_clients)))
tex('support.tex','Support for local test metrics','tab:support','lrrrr',['Dataset','Client $n$','Client $+$','Zero-positive / total','AP / AUROC clients'],[[DN[r['dataset']],r['client_n'],r['positive'],f'{r["zero_positive"]}/{r["client_splits"]}',r['ap_defined']+' / '+r['auroc_defined']] for r in loc],True,'Client ranges pool eight clients over ten seeds. Counts of clients with defined AP or AUROC range across seeds, with at most eight per run. They do not vary across methods within a seed.')
pd.DataFrame(loc).to_csv(OUT/'local_support_summary.csv',index=False)
secrows=[]
for d in DS:
    for m in ['non_private','fixed_dp','gate_frozen','gate_learned']:
        r=piv.loc[d,m];secrows.append([DN[d],MN[m],f'{r.auroc:.4f}',f'{r.brier:.4f}',f'{r.ece:.4f}'])
    base=ev[ev.dataset==d].groupby('seed').training_prevalence_baseline_brier.first().mean();secrows.append([DN[d],'Training-prevalence reference','0.5000',f'{base:.4f}','--'])
tex('secondary.tex','Selected secondary metrics averaged across ten seeds','tab:secondary','llrrr',['Dataset','Method','AUROC','Brier','ECE'],secrows,True,'Lower Brier and ECE values are preferable. The reference predicts the training prevalence. All 14 methods and individual runs appear in the supplement. These endpoints do not replace the primary AP comparison.')
# Aggregate Monte Carlo errors by valid draw counts; never treat invalid exact AP as zero.
hist=[];undefined=[];binned=[]
for job in lock['jobs']:
    p=ROOT/'runs'/job['job_id']/'histogram_audit_PUBLIC_ONLY.csv'
    if not p.exists():continue
    f=pd.read_csv(p);f['dataset']=job['dataset'];f['job_id']=job['job_id'];f['method']=job['method'];f['seed']=job['seed'];hist.append(f)
h=pd.concat(hist,ignore_index=True);hr=[]
for (d,b,m),g in h.groupby(['dataset','bins','multiplier']):
    valid=g.error.notna();undef=g.exact_ap.isna(); bvals=g.drop_duplicates(['job_id','client']).copy();be=bvals.binned_ap-bvals.exact_ap
    hr.append(dict(dataset=d,bins=int(b),multiplier=float(m),draws=len(g),defined_errors=int(valid.sum()),bias=float(g.loc[valid,'error'].mean()),mae=float(g.loc[valid,'absolute_error'].mean()),rmse=float(np.sqrt(g.loc[valid,'squared_error'].mean())),undefined_exact=int(undef.sum()),numeric_when_undefined=int((undef&g.noisy_ap.notna()).sum()),undefined_noisy=int(g.noisy_ap.isna().sum()),binned_defined_models=int(be.notna().sum()),binned_mae=float(be.abs().mean())))
hh=pd.DataFrame(hr);hh.to_csv(OUT/'histogram_error_summary.csv',index=False)
hs=hh[(hh.bins==30)&(hh.multiplier==1)].set_index('dataset').loc[DS]
tex('histogram.tex','Histogram AP error at 30 bins and the standard evaluation reserve','tab:histogram','lrrrrrr',['Dataset','Defined errors / draws','Bias','MAE','RMSE','Binning MAE','Numeric / undefined exact'],[[DN[d],f'{int(r.defined_errors):,}/{int(r.draws):,}',f'{r.bias:+.4f}',f'{r.mae:.4f}',f'{r.rmse:.4f}',f'{r.binned_mae:.4f}',f'{int(r.numeric_when_undefined):,}/{int(r.undefined_exact):,}'] for d,r in hs.iterrows()],True,'The audit fixes each final model and its local test records. It pools eight private main methods, ten seeds, eight clients, and 30 perturbations. Binning MAE uses unique model--client pairs with defined exact AP. Undefined exact metrics never receive a zero surrogate. The final column counts numerical noisy outputs despite undefined exact AP.')
report.update(histogram_draws=len(h),histogram_defined_errors=int(h.error.notna().sum()),histogram_numeric_with_undefined_exact=int((h.exact_ap.isna()&h.noisy_ap.notna()).sum()),histogram_undefined_exact=int(h.exact_ap.isna().sum()));write(OUT/'artifact_audit.json',report)
# Descriptive gate-versus-fixed contrast, added after execution; explicitly not a primary hypothesis.
gf=[]
for d in DS:
    z=ev[ev.dataset==d].pivot(index='seed',columns='method',values='common_mean_head_ap');m,l,u=mean_ci(z.gate_learned-z.fixed_dp);gf.append(dict(dataset=d,mean_difference=m,ci_low=l,ci_high=u,posthoc_descriptive=True))
pd.DataFrame(gf).to_csv(OUT/'gate_vs_fixed_DESCRIPTIVE.csv',index=False)
# Publication figures use every seed; no best-run selection.
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,axs=plt.subplots(1,4,figsize=(7.05,2.5),sharey=True)
for ax,d in zip(axs,DS):
    z=ev[ev.dataset==d].pivot(index='seed',columns='method',values='common_mean_head_ap');v=(z.gate_learned-z.gate_frozen).values;r=primary.loc[d]
    ax.axhline(0,color='.5',lw=.8);ax.scatter(np.linspace(-.12,.12,len(v)),v,s=18,color='#147D92',alpha=.85)
    ax.errorbar(.42,r.mean_difference,yerr=[[r.mean_difference-r.t_ci_low],[r.t_ci_high-r.mean_difference]],fmt='o',color='#A94724',capsize=4)
    ax.set_xlim(-.25,.65);ax.set_xticks([0,.42],['Seeds','Mean\n95% CI']);ax.set_title(DN[d].replace(' ','\n'));ax.grid(axis='y',alpha=.15)
axs[0].set_ylabel('Learned gate − frozen gate AP');fig.tight_layout();fig.savefig(PAPER/'figures/primary_effects.pdf');fig.savefig(PAPER/'figures/primary_effects.png',dpi=200);plt.close(fig)
fig,axs=plt.subplots(2,2,figsize=(7.05,4.3))
for ax,d in zip(axs.flat,DS):
    for b,color in zip([10,30,60],['#147D92','#A94724','#60558B']):
        g=hh[(hh.dataset==d)&(hh.bins==b)].sort_values('multiplier');ax.plot(g.multiplier,g.mae,'o-',label=f'{b} bins',color=color,ms=4)
    ax.set_xscale('log',base=4);ax.set_xticks([.25,1,4],['0.25','1','4']);ax.set_title(DN[d]);ax.set_ylabel('Histogram AP MAE');ax.set_xlabel('Evaluation-cost multiplier');ax.grid(alpha=.15)
axs[0,0].legend(frameon=False,fontsize=8);fig.tight_layout();fig.savefig(PAPER/'figures/histogram_error.pdf');fig.savefig(PAPER/'figures/histogram_error.png',dpi=200);plt.close(fig)
print(json.dumps(report,indent=2),flush=True)
