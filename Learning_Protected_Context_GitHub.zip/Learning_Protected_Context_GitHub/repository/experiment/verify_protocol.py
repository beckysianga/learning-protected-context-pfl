"""Targeted integration checks for resume identity and the final evaluation barrier."""
import json
from pathlib import Path
import tempfile
import numpy as np
from run_parallel import load


def main():
    m=load();checks=m.self_tests()['checks'];rng=np.random.default_rng(1001)
    X=rng.random((128,7));y=np.tile([0,1],64)
    V=rng.random((48,7));v=np.tile([0,1],24)
    data=m.TrainingData(X,y,V,v,list(np.array_split(np.arange(128),8)),list(np.array_split(np.arange(48),8)),'synthetic-check')
    job=dict(dataset='Cervical_Cancer',seed=42,alpha=.5,epsilon=16.,method='gate_learned',
             context_fraction=.15,feedback='brier',rounds=12,suite='integration_test',block_id='synthetic')
    job['job_id']=m.digest(job)[:20];protocol='synthetic-not-a-study'
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary);complete=root/'complete';resumed=root/'resumed'
        m.train_job(data,job,complete,protocol)
        m.train_job(data,job,resumed,protocol,stop_after_round=5)
        m.train_job(data,job,resumed,protocol)
        with np.load(complete/'final_model.npz') as a,np.load(resumed/'final_model.npz') as b:
            assert set(a.files)==set(b.files)
            assert all(np.array_equal(a[k],b[k]) for k in a.files)
        assert json.loads((complete/'decision_log_PUBLIC_ONLY.json').read_text())==json.loads((resumed/'decision_log_PUBLIC_ONLY.json').read_text())
        checks.append('interrupted and resumed training exactly matches uninterrupted models and decisions')
        summary=json.loads((complete/'training_summary.json').read_text())
        assert summary['allocation_training_updates']>0 and summary['gate_training_updates']>0
        assert summary['actions_after_update']>0 and summary['gate_decisions_after_update']>0
        checks.append('both controllers update before later actions in integration run')
        lock=dict(protocol_sha256=protocol,jobs=[job],bundles={})
        try:m.evaluation_gate(root,lock);raise AssertionError('Incomplete study was allowed to evaluate')
        except RuntimeError as exc:assert 'incomplete' in str(exc)
        checks.append('evaluation blocks incomplete planned model sets')
        assert not (root/'EVALUATION_OPENED.json').exists()
        checks.append('failed evaluation gate leaves test closed')
        with (complete/'final_model.npz').open('ab') as stream:stream.write(b'tampered')
        try:m.verify_complete(complete,'TRAIN_COMPLETE.json',protocol);raise AssertionError('Tampered model accepted')
        except RuntimeError as exc:assert 'changed' in str(exc)
        checks.append('completion verification rejects a modified final model')
    result=dict(passed=True,count=len(checks),checks=checks,environment=m.environment())
    destination=Path(__file__).with_name('integration_checks.json')
    destination.write_text(json.dumps(result,indent=2)+'\n')
    print('INTEGRATION CHECKS PASSED',len(checks),flush=True)


if __name__=='__main__':main()
