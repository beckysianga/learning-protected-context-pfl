PAPER 4: CORRECTED, REPEATED-SEED STUDY (DP-CAST-R v5.0)

This package develops the four-dataset Paper 4. It keeps the old v4.1 evidence
separate. The new source does not overwrite the old experiment archives.

WHAT CHANGED
1. Glioma age strings are parsed as years plus days/365.25. Genuine missing
   values remain missing. Malformed nonmissing values raise an error.
2. Numeric parsing cannot silently turn a feature into missing values. Feature
   audits report missingness, variance, clipping, and categorical hash collisions.
3. Exact source hashes identify all four original CSVs. The original Glioma
   file has 862 rows; the processed 839-row file is not silently substituted.
4. A fixed profile-group holdout is shared by every development and final seed.
   Training/validation allocation varies within the remaining records. Identical
   encoded profiles never cross train, validation, and test within a run.
5. The core protocol has ten seeds, four datasets, nine main methods, five
   acquisition ablations, 60 rounds, alpha=0.5, and epsilon=16 at delta=1e-5.
   This is 560 training runs. The separate development protocol has 56 runs,
   seed 42, and 30 rounds. Core seeds are 142,152,...,232.
6. Final test scoring is blocked until every planned model is complete. The
   evaluation gate commits the exact final model hashes and common holdout
   membership. Interrupted training resumes from saved state. The locked source,
   configuration, and numerical environment cannot change within a study.
7. The analysis reports all runs, paired seed differences, t and bootstrap
   intervals, sign-flip tests, and Holm adjustments. It does not treat heads,
   datasets, or histogram noise draws as independent training seeds.

THE FIVE ACQUISITION ABLATIONS
gate_periodic: query on the first and every second subsequent client visit.
gate_random: query with probability 0.5; force the first query for each client.
gate_no_recycle: learn the gate but always pay for a fresh context query. Discard
   the result when the gate requests reuse. This preserves the total accounted
   cost while removing the gradient-budget benefit of skipping a query.
gate_constant: both controllers learn; every acquired five-coordinate context
   is replaced by 0.5. Feedback, progress, ledger state, and age remain available.
gate_noise_only: both controllers learn; acquired context is replaced by an
   independent synthetic noisy vector. It does not subtract the protected data
   release or reveal its noise. The original release cost remains charged.

Constant/noise controls remove the five context coordinates, not all private
feedback. First visits always request a query. Each comparison concerns the
complete coupled procedure; it does not identify one isolated causal pathway.

RUN IN COLAB OR JUPYTER
The entire experiment/DP_CAST_v5_SingleCell.py file can run in one cell.
It defaults to a development run and scores validation data only.
For the final sequential experiment, set DPCAST_PHASE=run before execution,
or change the operational PHASE line. Set DPCAST_STUDY to a persistent path.
Do not change the configuration after locking. Colab may interrupt long runs;
preserve the entire study directory and resume with the same source/environment.

COMMAND-LINE WORKFLOW
    python experiment/verify_protocol.py
    DPCAST_PHASE=development python experiment/DP_CAST_v5_SingleCell.py
    DPCAST_PHASE=lock python experiment/DP_CAST_v5_SingleCell.py
    DPCAST_PHASE=train python experiment/DP_CAST_v5_SingleCell.py
    DPCAST_PHASE=evaluate python experiment/DP_CAST_v5_SingleCell.py

Set environment variables using the syntax appropriate for your operating
system. DPCAST_DOWNLOAD=0 suppresses automatic notebook downloads.
DPCAST_LOCAL_CSV accepts a JSON mapping from dataset names to original CSV paths.
Without local files, the script downloads the documented original sources and
verifies their hashes. No dataset is silently skipped and no row cap is applied.

PARALLEL WORKFLOW
    python experiment/run_parallel.py --stage development --root /path/dev --workers 4
    python experiment/run_parallel.py --stage final --root /path/study --workers 4

Optional --local-sources /path/mapping.json supplies the same CSV mapping.
Workers write disjoint run folders. If a worker fails, inspect worker_logs and
resume the SAME command. A failed/incomplete run is never dropped from inference.
Do not launch two orchestrators against the same root at the same time.

The extended profile is separate: DPCAST_PROFILE=extended uses alpha 0.1,0.5,1.0
and epsilon 8,16,32. It has 3,200 runs, including the five anchor ablations.
Use a separate directory and lock. Completing the core study does not establish
results for those unexecuted privacy/heterogeneity settings.

STATISTICAL INTERPRETATION
Primary endpoint: mean AP over eight personalized heads on the same fixed test
records. Primary contrast: gate_learned minus gate_frozen, by dataset. Both arms
train allocation. The core study has one condition per seed. An extended study
first averages conditions within each seed. Holm adjustment covers the four
primary dataset tests. Secondary and ablation families are labelled separately.
Sign-flip inference assumes paired-label exchangeability/symmetric null
differences. t intervals assume approximately normal seed differences. Intervals
describe simulation variation conditional on these fixed benchmarks. They do
not describe uncertainty for a new hospital population. A confidence interval
that includes zero does not demonstrate equivalence. The 0.005 AP margin is a
prespecified descriptive threshold, not a clinically validated threshold.

PRIVACY AND EVALUATION SCOPE
All datasets are public benchmarks. Exact predictions, labels, support counts,
and seeded noise are public research diagnostics with NO DP release guarantee.
The matched epsilon refers to the configured conservative ideal-mechanism bound.
The conditional record-replacement argument assumes fixed membership, splits,
sizes, schemas, bounds, a trusted client custodian, and secret Gaussian noise.
It excludes label-dependent partition creation, exact diagnostic exports, and
cross-study tuning unless separately accounted. A deployment needs expert review.

Earlier experiments inspected these public datasets. A fixed new holdout improves
procedural separation in v5, but it does not erase that history or create a new
external cohort. No clinical-readiness, priority, acceptance, or reviewer-score
guarantee is made. Negative results and unchanged policies remain reportable.

The old plan proposed 3,840 runs. This prospectively specified v5 core protocol
replaces that plan for the present study; it is not represented as completion of
the old plan. Local locks establish traceability, not independent preregistration.

MANUSCRIPT AND AUTHOR BLOCK
Title: Learning When to Acquire Protected Context for Personalized Federated Learning
Authors, in the supplied order:
  Rebecca Adhiambo Okaka — Department of Computing
  Evanson Mwangi Karanja — Department of Computing
  Isaac Nyabisa Oteyo — Department of Information Technology
Institution: Jomo Kenyatta University of Agriculture and Technology
The manuscript preserves the Nairobi, Kenya address and emails from the earlier
three-author source. The most recent uploaded Paper 4 omitted two coauthors.

REBUILD THE PAPER EVIDENCE AFTER THE ENTIRE FINAL STUDY COMPLETES
    python experiment/build_paper_evidence.py /path/core_study paper
The script verifies committed hashes and recomputes AP, AUROC, Brier, and ECE
from every saved head prediction vector. It also checks paired initialization,
schedules, seed coverage, and fixed holdout membership. It creates publication
tables and figures. The narrative must describe the completed results honestly.
Compile paper/main.tex with pdflatex, bibtex, pdflatex, then pdflatex.
The editable source uses IEEEtran conference format. A target venue may impose
a different page limit or anonymity rule. No venue-specific submission was made.

COMPLETED EXECUTION AND AUDIT
All 56 development runs and all 560 final runs completed. Final evaluation
opened only after all 560 model hashes were committed. No seed was excluded.
The paper audit verified 7,040 committed file hashes and 38,080 metric entries
from 4,480 prediction vectors. Maximum finite metric discrepancy: 3.89e-16.
The histogram audit contains 691,200 draws; 583,182 have defined paired errors.

Primary mean AP differences (learned gate minus frozen gate):
  Cervical Cancer: -0.005210; 95% paired t CI [-0.025895, +0.015475]
  CDC Diabetes:    +0.000190; 95% paired t CI [-0.000718, +0.001098]
  Glioma Grading:  +0.010091; 95% paired t CI [-0.049074, +0.069256]
  SUPPORT2:        +0.005649; 95% paired t CI [-0.008978, +0.020276]
All four Holm-adjusted primary p-values equal 1.00. No secondary comparison or
acquisition ablation passes its labelled Holm-adjusted family. These findings
do not establish a learned-gate utility benefit or equivalence. Several tasks
show weak discrimination and poor probability calibration. The paper reports
these limits; it does not claim a desired novelty score or publication outcome.

The raw results archive includes both development/ and core_study/, with source
snapshots, raw public CSVs, checkpoints, final models, predictions, decision logs,
privacy ledgers, histogram audit draws, and all per-seed comparisons. The source
archive includes the final IEEE manuscript and its derived tables and figures.

RESULTS DOWNLOAD PARTS
The saved results are distributed as four ordinary ZIP files named
DP_CAST_Paper4_v5_Results_Part1.zip through Part4.zip. Extract all four into
the SAME destination folder. They contain disjoint files under core_study/
and development/. No binary concatenation is needed. Keep all four parts.
The full ARCHIVE_MANIFEST.json appears in the extracted root and covers the
complete experiment. The source ZIP is separate.
