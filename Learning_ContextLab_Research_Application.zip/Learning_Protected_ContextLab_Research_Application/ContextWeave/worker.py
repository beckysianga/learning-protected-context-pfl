"""One isolated experiment process, with real progress and persistent artifacts."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
import sys,time,traceback,zipfile,shutil,html
from common import *

def summarize(folder,request,rows,traces,heads):
 from scipy import stats
 df=pd.DataFrame(rows);groups=[]
 metrics=['ap','auroc','brier','worst_head_ap','ap_dispersion','recall','specificity','f1','epsilon','query_rate','controller_updates','runtime_seconds']
 for method,part in df.groupby('method',sort=False):
  row={'method':method,'label':META['methods'][method],'seeds':len(part)}
  for key in metrics:
   a=pd.to_numeric(part[key],errors='coerce');row[key]=float(a.mean()) if a.notna().any() else None
  row['ap_sd']=float(part.ap.std(ddof=1)) if len(part)>1 else None;groups.append(row)
 summary=pd.DataFrame(groups);safe_csv(df,folder/'results.csv');safe_csv(summary,folder/'comparison.csv');safe_csv(pd.DataFrame(heads),folder/'head_metrics.csv');safe_csv(pd.DataFrame(traces),folder/'training_curves.csv')
 reference='gate_frozen' if META['engine']=='acquisition' else 'fixed';pairs=[]
 if reference in set(df.method):
  ref=df[df.method==reference].set_index('seed')
  for method,part in df.groupby('method',sort=False):
   if method==reference:continue
   paired=part.set_index('seed')[['ap']].join(ref[['ap']],lsuffix='_candidate',rsuffix='_reference',how='inner')
   diff=paired.ap_candidate-paired.ap_reference;n=len(diff);mean=float(diff.mean());half=float(stats.t.ppf(.975,n-1)*diff.std(ddof=1)/np.sqrt(n)) if n>1 else None
   pairs.append({'method':method,'reference':reference,'paired_seeds':n,'mean_ap_difference':mean,'ci95_low':mean-half if half is not None else None,'ci95_high':mean+half if half is not None else None,'interpretation':'Exploratory, unadjusted paired t interval; seeds are replicates.' if n>1 else 'One seed: descriptive difference only; no confidence interval.'})
 safe_csv(pd.DataFrame(pairs),folder/'paired_comparisons.csv')
 curves=[]
 from sklearn.metrics import precision_recall_curve,roc_curve
 for row in rows:
  path=folder/'study/runs'/row['run_id']/('predictions_PUBLIC_ONLY.npz' if META['engine']=='acquisition' else 'test_predictions.npz')
  with np.load(path,allow_pickle=False) as z:
   if META['engine']=='acquisition':y=z['labels'];p=np.mean([z[f'head_{i}'] for i in range(request['config']['clients'])],axis=0)
   else:y=z['y'];p=z['p'].mean(axis=0)
  precision,recall,_=precision_recall_curve(y,p);fpr,tpr,_=roc_curve(y,p)
  def down(x,y):
   ix=np.unique(np.linspace(0,len(x)-1,min(150,len(x))).astype(int));return [{'x':float(x[i]),'y':float(y[i])} for i in ix]
  curves.append({'method':row['method'],'seed':row['seed'],'pr':down(recall,precision),'roc':down(fpr,tpr)})
 result=clean({'app':META['name'],'name':request['config']['name'],'dataset':request['filename'],'created':request['created'],'completed':now(),'engine':META['engine'],'runs':rows,'summary':groups,'traces':traces,'heads':heads,'paired':pairs,'curves':curves,'source':'New computation on uploaded data','prediction_audit':read(folder/'metric_audit.json'),'release_dp_claim':False,'metric_definition':'AP is non-interpolated average precision, averaged over head proxies on a common held-out test set. Curves use the ensemble score and therefore have a different estimand.','privacy_unit':META['unit'],'notes':['Uploaded-data experiments are adaptations of the paper engines, not a reproduction of the paper’s complete benchmark grid.','Configured privacy targets describe individual idealized mechanisms. The diagnostic archive, exact metrics, preprocessing, seeded randomness, and multiple runs do not constitute an end-to-end private release.','Intervals compare seeds on one fixed dataset; they do not measure external-population uncertainty.','Model and data hashes identify each experiment. Final testing begins only after all planned models are committed.']})
 save(folder/'results.json',result)
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
 fig,ax=plt.subplots(figsize=(9,max(3,len(groups)*.36+1)))
 ax.barh([g['label'] for g in groups],[g['ap'] for g in groups],color=META['accent'],xerr=[g['ap_sd'] or 0 for g in groups],capsize=3)
 ax.set_xlabel('Mean held-out head AP (error bars: SD across seeds)');ax.set_xlim(0,1);ax.invert_yaxis();ax.grid(axis='x',alpha=.15);fig.tight_layout()
 fig.savefig(folder/'comparison.svg');fig.savefig(folder/'comparison.png',dpi=180);plt.close(fig)
 esc=html.escape
 report='<html><head><meta charset="utf-8"><title>'+esc(request['config']['name'])+'</title><style>body{font:16px/1.6 system-ui;max-width:1000px;margin:48px auto;color:#183440;padding:24px}h1{font-size:36px}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:left}.note{background:#eef5f3;padding:18px}img{max-width:100%}</style></head><body><small>'+META['name']+' · Research report</small><h1>'+esc(request['config']['name'])+'</h1><p>'+esc(request['filename'])+' · '+esc(now())+'</p><div class="note">'+esc(result['metric_definition'])+'</div><img src="comparison.svg" alt="Average precision by method">'+summary.to_html(index=False,escape=True,float_format=lambda x:f'{x:.5f}')+'<h2>Interpretation and scope</h2><ul>'+''.join('<li>'+esc(n)+'</li>' for n in result['notes'])+'</ul><h2>Configuration</h2><pre>'+esc(json.dumps(request['config'],indent=2))+'</pre><h2>Verification</h2><p>Saved-prediction metric audit: '+('passed' if result['prediction_audit']['all_passed'] else 'failed')+'</p></body></html>'
 (folder/'report.html').write_text(report,encoding='utf-8')
 return result

def export(folder):
 archive=folder/'experiment.zip'
 excluded={'normalized','data','bundles','public_sources','LOCAL_RESTART_STATE_NOT_A_RELEASE'}
 items=[]
 for p in sorted(folder.rglob('*')):
  rel=p.relative_to(folder)
  if not p.is_file() or excluded.intersection(rel.parts) or p.name in ['input.csv','experiment.zip','status.json','run.log'] or 'checkpoint' in p.name or p.suffix=='.tmp':continue
  items.append(p)
 save(folder/'export_manifest.json',{'files':{str(p.relative_to(folder)):sha(p) for p in items},'excludes':'Raw input CSV, preprocessed training/test arrays, local restart checkpoints and noise roots.','contains':'Models, exact test labels and predictions, diagnostics, configuration, source, reports; this is not a confidential release.'})
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for p in items+[folder/'export_manifest.json']:z.write(p,folder.name+'/'+str(p.relative_to(folder)))

def main(folder):
 folder=Path(folder).resolve();request=read(folder/'request.json');start=time.time()
 def progress(stage,done,total,round_,rounds,method,trace=None):
  pct=5+85*(done+round_/max(rounds,1))/max(total,1) if stage=='training' else 92+5*done/max(total,1) if stage=='evaluating' else 2
  save(folder/'status.json',dict(id=folder.name,name=request['config']['name'],stage=stage,percent=min(pct,99),done=done,total=total,round=round_,rounds=rounds,method=method,elapsed_seconds=time.time()-start,updated=now(),created=request['created'],latest=trace or {}))
 try:
  progress('preparing',0,len(request['config']['methods'])*len(request['config']['seeds']),0,request['config']['rounds'],'Checking data')
  if sha(folder/'input.csv')!=request['input_sha256']:raise RuntimeError('Input file changed after run creation.')
  current={str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'app.json',ROOT/'worker.py',ROOT/'adapter.py',ROOT/'common.py',*sorted((ROOT/'engine').rglob('*.py'))]}
  if current!=request['application_source_sha256']:raise RuntimeError('Application source changed after run creation.')
  save(folder/'environment.json',environment())
  source=folder/'source';source.mkdir(exist_ok=True)
  shutil.copy2(ROOT/'app.json',source/'app.json')
  for name in current:
   p=source/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,p)
  from adapter import run_acquisition,run_sparse
  rows,traces,heads=(run_acquisition if META['engine']=='acquisition' else run_sparse)(folder,request,progress)
  summarize(folder,request,rows,traces,heads);export(folder)
  status=read(folder/'status.json');status.update(stage='completed',percent=100,done=status['total'],elapsed_seconds=time.time()-start,updated=now());save(folder/'status.json',status)
  print('Completed. Saved predictions passed the metric audit.',flush=True)
 except Exception as exc:
  traceback.print_exc();status=read(folder/'status.json');status.update(stage='failed',error=str(exc),updated=now(),elapsed_seconds=time.time()-start);save(folder/'status.json',status);return 1
 return 0
if __name__=='__main__':sys.exit(main(sys.argv[1]))
