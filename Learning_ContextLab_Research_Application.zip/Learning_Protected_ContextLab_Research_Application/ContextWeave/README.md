# ContextWeave Research Studio

Learn when context is worth acquiring.

A working local web application for **Learning to Acquire Protected Context for Personalized Federated Learning**. It runs the paper's NumPy research engine behind a responsive, offline interface. It is a federated-learning simulator on one computer, not a distributed hospital network or a certified private-release system.

## Start on Windows

1. Install **64-bit Python 3.12**. Select “Add Python to PATH” during installation. Python 3.13 is also accepted by the launcher; validation used 3.12.
2. Extract the entire ZIP. Do not run files from inside the compressed folder.
3. Open the `ContextWeave` folder and double-click **START_WINDOWS.bat**.
4. On the first launch, allow the terminal to finish creating `.venv` and installing the pinned packages. This requires internet access and can take several minutes.
5. Your default browser opens at **http://127.0.0.1:8765**. Keep the terminal window open while working.

If double-clicking does not work, open a terminal in this folder and run:

```text
py -3.12 launch.py
```

## Start on macOS or Linux

Install Python 3.12, extract the ZIP, open a terminal in this folder, and run:

```bash
bash START_MAC_LINUX.sh
```

You can also run `python3 launch.py`. On Linux, install your distribution's Python venv package if the interpreter reports that venv/ensurepip is unavailable. Only the first dependency installation needs internet access; the interface, sample data, reference evidence, and uploaded-data experiments run locally.

## Existing Python environment

```bash
python -m pip install -r requirements.txt
python run.py
```

Use `python run.py --port 8770` if the default port is occupied. `--no-browser` suppresses automatic browser opening. The server always binds to 127.0.0.1. Do not expose this desktop server directly to the public internet.

## First experiment

1. Open **Data workspace → Load demonstration data**.
2. Select `outcome` as the target and `positive` as the positive class.
3. Review the selected predictors. Click **Validate dataset**, then continue.
4. In **Experiment design**, select the Quick start preset. Review all parameters and click **Validate & run experiment**.
5. Watch **Experiment runs**. Once complete, select **Explore results**.
6. Download metrics, figures, the report, or the complete experiment archive.

The sample contains 800 synthetic records and is clearly labeled. It is for software testing, not clinical research evidence. The paper evidence page displays separately audited original results.

## Use your own raw data

- Upload CSV/TSV, up to 50 MB, with 2–150 columns and at most 300,000 records.
- Execution requires at least max(100, 12 × clients) records and at least 20 records in each outcome class. Splitting may still fail on pathological or highly duplicated data; the app reports that failure rather than retrying until it obtains a favorable split.
- Choose exactly one binary outcome, its positive label, and your predictors. Missing outcome labels are rejected. Missing predictors are supported.
- Review numeric, categorical, and age-in-years/days feature types. The age parser preserves fractional years from values such as `50 years 183 days`, rejecting malformed values. Known mutation strings use the original MUTATED/NOT_MUTATED mapping.
- Known paper outcome columns suggest the original benchmark exclusions. ContextWeave additionally suggests the original fixed feature schema. Review these suggestions: they are not a universal leakage detector.
- Exclude identifiers, post-outcome fields, and label proxies. No patient identifier, institution membership, or longitudinal grouping is inferred.
- ContextWeave uses fixed numeric bounds and 8 categorical hash buckets from the original transform. For arbitrary columns, bounds are initially suggested from the uploaded file; review and set domain-appropriate bounds. Data-derived schema choices are outside any private-release claim.

## What you can configure

Experiment name, method set, training seeds, rounds, number of simulated clients, participation probability, Dirichlet heterogeneity, epsilon, delta, local learning rate, local steps/epochs, batch size, clipping threshold, encoder/head widths, dropout, focal loss, controller replay batch, and context/clipping/evaluation budget shares. Acquisition defaults preserve the gate and allocation logic.

Preset settings are applied to **the currently selected file**. They do not by themselves reproduce the paper's full dataset, split, or experiment grid. The earlier Cervical results in CASTLab remain historical evidence; new uploaded-data runs use the revised sparse-feedback engine.

## Results and reproducibility

Every experiment has its own immutable request, input hash, source hashes, environment record, method–seed jobs, model commitments, and saved results. All selected models finish before the final test arrays are scored. Exact prediction metrics are recomputed before the application marks a run completed.

The primary UI metric is non-interpolated AP averaged across personalized head proxies on a common held-out test set. Ensemble precision–recall curves have a different estimand. Mean ± SD summarizes training seeds. One seed has no confidence interval. Paired t intervals with multiple seeds are exploratory and unadjusted; client heads are not treated as independent replicates.

Downloads include CSV tables, SVG/PNG figures, HTML report, settings, model files, prediction arrays, ledgers, diagnostics, and the source snapshot. The complete ZIP excludes the original raw CSV, training/test feature arrays, restart checkpoints, and private noise roots. It **does include exact held-out labels and prediction scores**, so it is not an anonymized or private-release archive. Keep your original raw file separately if you want to repeat the study. Import the saved request/settings into the same app after uploading that file.

Open `report.html` with `comparison.svg` beside it, or use the complete archive to preserve that relationship. The source snapshot records the execution code; run the full application distribution to launch the interface.

## Workspace and recovery

Data and experiment directories are stored under `workspace/`. Close the application before backing up or manually removing them. You may set `RESEARCH_APP_WORKSPACE` to another directory before launch. Never put confidential data in a publicly shared folder.

Only one study runs at a time. The interface supports cancellation and cloning a configuration into a fresh study. The underlying engine checkpoints are preserved locally, but the UI deliberately does not resume an interrupted experiment automatically. Failed runs remain visible with logs. A server crash can leave `workspace/APP_LOCK.json`; verify that the old app **and its worker processes** have stopped before removing this app ownership lock. Do not change an engine protocol lock.

## What is verified

See `VALIDATION.md` and the machine-readable records under `validation/`. Functional tests trained every UI method, checked downloads and rejection paths, and compared saved predictions with metrics. Separate tests checked age-string preprocessing. All seven interface views were executed in DOM tests with real result fixtures. Browser screenshots and native Windows/macOS launcher execution were unavailable in the build environment; these are explicitly unverified. The generated comparison figure was inspected visually.

To repeat the functional tests in the installed environment:

```bash
python tests/functional.py
python tests/data_regression.py
```

These tests use temporary synthetic data and do not overwrite your workspace. They may take several minutes depending on the CPU. Tests of the interface's source are not included as a runtime dependency.

## Project layout

| File / folder | Purpose |
| --- | --- |
| START_WINDOWS.bat / START_MAC_LINUX.sh | Start the local app |
| launch.py | Create environment and install pinned dependencies |
| run.py | Local API, workspace, worker lifecycle, file downloads |
| adapter.py / worker.py / common.py | Data adapter, execution, reporting, validation |
| static/ | Responsive interface, local CSS and JavaScript; no CDN |
| engine/ | Vendored research engine and retained original versions |
| reference/ | Paper PDF, original evidence tables and source notices |
| validation/ | Actual validation records |
| SOURCE_ANALYSIS.md | Source findings, evidence scope, and adaptations |

Research attribution: Rebecca Adhiambo Okaka, Evanson Mwangi Karanja, Isaac Nyabisa Oteyo. Original notices remain in `reference/SOURCE_LICENSE_NOTICE.md` and `reference/SOURCE_CITATION.cff`. No new license or publication status is asserted by this packaging.
