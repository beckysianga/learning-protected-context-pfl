"""Explicit adapters to the archived NumPy engines; numerical training is retained."""
import sys,importlib.util,hashlib,json,shutil
from pathlib import Path
import numpy as np
import pandas as pd
from common import *

def prepared_input(folder,request):
 frame=csv_frame((folder/'input.csv').read_text(encoding='utf-8'))
 validate_data(frame,request['schema'],request['config']['clients'])
 schema=request['schema'];out=pd.DataFrame()
 for i,f in enumerate(schema['features']):
  values=frame[f['name']]
  if f['kind']=='age':values=values.map(age_years)
  elif f['kind']=='numeric':values=values.map(lambda x:NUMERIC_MAP.get(x,x))
  out['x'+str(i)]=values
 out['outcome']=(frame[schema['target']].astype(str).str.strip()==str(schema['positive']).strip()).astype(int)
 save(folder/'feature_mapping.json',{'target':schema['target'],'positive':schema['positive'],'features':[{**f,'encoded_input':'x'+str(i)} for i,f in enumerate(schema['features'])]})
 return out

def run_acquisition(folder,request,progress):
 spec=importlib.util.spec_from_file_location('weave_engine',ROOT/'engine/v5.py')
 e=importlib.util.module_from_spec(spec);sys.modules[spec.name]=e;spec.loader.exec_module(e)
 c=request['config'];frame=prepared_input(folder,request)
 e.C.update(datasets=['Uploaded'],minimum_datasets=1,seeds=c['seeds'],alphas=[c['alpha']],epsilons=[c['epsilon']],rounds=c['rounds'],clients=c['clients'],participation=c['participation'],delta=c['delta'],encoder=c['encoder'],head=c['head'],lr=c['local_lr'],head_lr=c['local_lr'],local_steps=c['local_steps'],memory_chunk=c['batch_size'],dropout=c['dropout'],base_clip=c['base_clip'],focal_alpha=c['focal_alpha'],focal_gamma=c['focal_gamma'],context_fraction=c['context_fraction'],clip_fraction=c['clip_fraction'],evaluation_fraction=c['evaluation_fraction'],learning_batch=c['learning_batch'],holdout_seed=c['holdout_seed'],main_methods=c['methods'],focused_ablations=False,acquisition_ablations=[],require_original_row_counts=False,checkpoint_every=1)
 e.K=c['clients'];e.DELTA=c['delta'];e.BATCH_CHUNK=c['batch_size'];e.BASE_CLIP=c['base_clip'];e.DROPOUT=c['dropout'];e.FOCAL_ALPHA=c['focal_alpha'];e.FOCAL_GAMMA=c['focal_gamma']
 e.eps_to_rho.__defaults__=(c['delta'],);e.rho_to_eps.__defaults__=(c['delta'],)
 e.DATASETS['Uploaded']={'target':'outcome','columns':[x for x in frame if x!='outcome'],'categorical':['x'+str(i) for i,f in enumerate(request['schema']['features']) if f['kind']=='category'],'bounds':{'x'+str(i):(float(f['low']),float(f['high'])) for i,f in enumerate(request['schema']['features']) if f['kind'] in ['numeric','age']}}
 e.get_frame=lambda name:(frame,{'source_sha256':sha(folder/'input.csv'),'target':request['schema']['target'],'source':'User-provided benchmark; custom application study'})
 study=folder/'study';study.mkdir(exist_ok=True)
 jobs=e.configurations(False)
 # Custom-data studies intentionally do not claim the original four-dataset inferential scope.
 for j in jobs:j['suite']='custom';j['job_id']=e.digest(j)[:20]
 bundles={}
 for j in jobs:
  if j['block_id'] not in bundles:bundles[j['block_id']]=e.make_bundle(study,j['dataset'],j['seed'],j['alpha'])
 save(folder/'preprocessing.json',e._TRANSFORM_REPORTS['Uploaded'])
 lock={'version':'ContextWeave-1.0','configuration':e.C,'jobs':jobs,'bundles':bundles,'application_source_sha256':request['application_source_sha256'],'input_sha256':request['input_sha256'],'scope':'Custom data research run, not reproduction of the full paper grid','release_dp_claim':False}
 lock['protocol_sha256']=e.digest(lock);save(study/'protocol_lock.json',lock)
 rows=[];details=[];trace=[];heads=[]
 for idx,j in enumerate(jobs):
  progress('training',idx,len(jobs),0,c['rounds'],j['method'])
  e.APP_PROGRESS=lambda r,total,t,idx=idx,j=j:progress('training',idx,len(jobs),r,total,j['method'],t)
  d=e.load_training(study,j);out=study/'runs'/j['job_id']
  summary=e.train_job(d,j,out,lock['protocol_sha256']);details.append(summary)
 e.evaluation_gate(study,lock)
 for idx,j in enumerate(jobs):
  progress('evaluating',idx,len(jobs),c['rounds'],c['rounds'],j['method'])
  result=e.evaluate_job(study,j,lock);out=study/'runs'/j['job_id'];s=details[idx]
  head=pd.read_csv(out/'common_head_metrics_PUBLIC_ONLY.csv');head['method']=j['method'];head['seed']=j['seed'];heads.extend(head.to_dict('records'))
  led=pd.read_csv(out/'final_accounting.csv') if j['method']!='non_private' else None
  rows.append(dict(run_id=j['job_id'],method=j['method'],seed=j['seed'],ap=result['common_mean_head_ap'],auroc=result['common_mean_head_auroc'],brier=result['common_mean_head_brier'],worst_head_ap=result['common_worst_head_ap'],ap_dispersion=result['common_head_ap_sd'],recall=float(head.recall.mean()),specificity=float(head.specificity.mean()),f1=float(head.f1.mean()),epsilon=float(led.epsilon.max()) if led is not None else None,query_rate=s['context_query_rate'],controller_updates=s['allocation_training_updates'],gate_updates=s['gate_training_updates'],runtime_seconds=s['elapsed_seconds'],valid_clients=result['valid_local_ap_clients'],test_n=result['n'],prevalence=result['test_prevalence_REFERENCE_ONLY']))
  for t in pd.read_csv(out/'rounds.csv').to_dict('records'):trace.append({**t,'method':j['method'],'seed':j['seed']})
 save(folder/'raw_results.json',{'runs':rows,'traces':trace,'heads':heads})
 audit=[]
 for j in jobs:
  out=study/'runs'/j['job_id'];saved=read(out/'evaluation.json')
  with np.load(out/'predictions_PUBLIC_ONLY.npz',allow_pickle=False) as z:
   metrics=[e.exact_metrics(z['labels'],z[f'head_{i}']) for i in range(e.K)]
  for short,long in [('ap','ap'),('auroc','auroc'),('brier','brier')]:
   value=float(np.mean([x[short] for x in metrics]));expected=saved['common_mean_head_'+long]
   audit.append({'run_id':j['job_id'],'metric':short,'passed':bool(np.isclose(value,expected,rtol=1e-10,atol=1e-12))})
 save(folder/'metric_audit.json',{'checks':audit,'all_passed':all(x['passed'] for x in audit)})
 if not all(x['passed'] for x in audit):raise RuntimeError('Saved predictions did not match reported metrics.')
 return rows,trace,heads

def run_sparse(folder,request,progress):
 sys.path.insert(0,str(ROOT/'engine'))
 import run as cli
 from dpcast import config,experiment,evaluate,common
 c=request['config'];frame=prepared_input(folder,request)
 cache=folder/'normalized';cache.mkdir(exist_ok=True);frame.to_csv(cache/'Uploaded.csv',index=False)
 save(cache/'Uploaded_metadata.json',{'source':'User-uploaded research data','variables':[{'name':'x'+str(i),'type':'categorical' if f['kind']=='category' else 'continuous','role':'feature'} for i,f in enumerate(request['schema']['features'])]})
 base_method=config.method
 def configured_method(name):
  m=base_method(name);m.context_fraction=c['context_fraction'];return m
 config.method=configured_method;experiment.method=configured_method
 base_manifest=common.source_manifest
 def manifest():return {**base_manifest(),**{'app/'+p.name:sha(p) for p in [ROOT/'adapter.py',ROOT/'worker.py',ROOT/'common.py']},'app/request.json':sha(folder/'request.json')}
 cli.source_manifest=manifest;evaluate.source_manifest=manifest
 cfg=config.Config(study_name='CASTLab_custom_'+folder.name,purpose='development',datasets=['Uploaded'],methods=c['methods'],seeds=c['seeds'],alphas=[c['alpha']],epsilons=[c['epsilon']],clients=c['clients'],rounds=c['rounds'],participation=c['participation'],local_epochs=c['local_steps'],batch_size=c['batch_size'],local_lr=c['local_lr'],encoder_dims=c['encoder'],head_hidden=c['head'],dropout=c['dropout'],focal_alpha=c['focal_alpha'],focal_gamma=c['focal_gamma'],delta=c['delta'],clip_init=c['base_clip'],clip_fraction=c['clip_fraction'],evaluation_fraction=c['evaluation_fraction'],rl_batch=c['learning_batch'],rl_warmup=c['learning_batch'],pretrain_epochs=c['pretrain_epochs'],split_seed=c['holdout_seed'],bootstrap_reps=c['bootstrap_reps'],max_rows=None,data_history='User-uploaded research data; benchmark simulation. Public partition assumptions must be assessed by the researcher.').validate()
 save(folder/'engine_config.json',cfg.to_dict());study=folder/'study'
 lock=cli.prepare(folder/'engine_config.json',study,cache)
 for idx,j in enumerate(lock['runs']):
  progress('training',idx,len(lock['runs']),0,c['rounds'],j['method'])
  experiment.APP_PROGRESS=lambda r,total,t,idx=idx,j=j:progress('training',idx,len(lock['runs']),r,total,j['method'],t)
  experiment.train_run(study,cfg,j)
 progress('evaluating',0,len(lock['runs']),c['rounds'],c['rounds'],'All committed models')
 evaluate.evaluate(study);audit=evaluate.audit_saved_predictions(study);save(folder/'metric_audit.json',audit)
 rows=[];trace=[];heads=[]
 for j in lock['runs']:
  out=study/'runs'/j['run_id'];r=read(out/'test_metrics.json');s=read(out/'complete.json');cert=read(out/'privacy_accounting.json')
  head=pd.read_csv(out/'test_heads.csv');head['method']=j['method'];head['seed']=j['seed'];heads.extend(head.to_dict('records'))
  rows.append(dict(run_id=j['run_id'],method=j['method'],seed=j['seed'],ap=r['mean_ap'],auroc=r['mean_auroc'],brier=r['mean_brier'],worst_head_ap=float(head.ap.min()),ap_dispersion=float(head.ap.std(ddof=0)),recall=r['mean_recall'],specificity=r['mean_specificity'],f1=r['mean_f1'],epsilon=j['epsilon'] if config.method(j['method']).private and j['method']!='raw_context' else None,query_rate=s['context_queries']/s['executed_updates'] if s['executed_updates'] else 0.,controller_updates=s['controller_updates'],gate_updates=None,runtime_seconds=s['runtime_seconds'],valid_clients=int(head.ap.notna().sum()),test_n=r['test_n'],prevalence=r['test_positives']/r['test_n'],selected_round=s['selected_round']))
  p=out/'rounds.csv'
  if p.stat().st_size>2:
   for t in pd.read_csv(p).to_dict('records'):trace.append({**t,'method':j['method'],'seed':j['seed']})
 save(folder/'preprocessing.json',read(study/'data/Uploaded/preprocessing.json'))
 save(folder/'raw_results.json',{'runs':rows,'traces':trace,'heads':heads})
 return rows,trace,heads
