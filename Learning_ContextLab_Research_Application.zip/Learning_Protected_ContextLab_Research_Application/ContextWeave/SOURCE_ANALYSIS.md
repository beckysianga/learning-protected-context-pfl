# Source analysis and implementation decisions — ContextWeave

## Evidence actually examined

The current formatted paper, the corresponding GitHub reproducibility package, its implementation, protocol/configuration files, documentation, saved outputs, source snapshots, and numerical evidence audits were examined. These two papers were kept separate throughout.

### Acquisition study

`Learning_Protected_Context_GitHub.zip` supplied the eight-page manuscript, v5 implementation, evidence builder, protocol checks, and derived evidence. All four `DP_CAST_Paper4_v5_Results_Part*.zip` assets were retrieved. The original restore tool verified all four asset checksums and **10,005 original manifest entries**. The original saved-evidence builder then verified **560 final runs, 4,480 head prediction vectors, 7,040 committed artifact hashes, and 38,080 metric values**, with maximum absolute metric discrepancy **3.885780586188048e-16**. All training models preceded the final test gate. The audit also processed 691,200 histogram draws.

The final study uses four datasets, fourteen methods/ablations, ten seeds (142 to 232 by tens), 60 rounds, alpha 0.5, epsilon 16 and delta 1e-5. The primary learned-versus-frozen gate comparison does not establish a utility benefit: every primary interval includes zero and every Holm-adjusted p-value is 1.00. The app preserves these negative findings.

The v5 engine uses a shared representation, personalized heads and encoder blending, per-example clipped mean gradients, a context-acquisition gate, and a clipping/allocation controller. It decides whether to request context before inspecting fresh context. Skipped query allocations return to gradients. Its ideal adjacency is **record replacement conditional on fixed memberships, schemas and other stated assumptions**. Its exported exact diagnostics and benchmark random streams are not a private release. Numeric conversion and fixed-bound transforms, including corrected Glioma years/days parsing, are material to the implementation.

### Sparse-feedback study

`DP_CAST_Sparse_Feedback_GitHub.zip` supplied the six-page manuscript, both earlier and revised code, reported configurations, executed-source snapshots, raw saved results, predictions, ledgers, models, and evidence audit. The original audit was rerun successfully: **462 consistency checks**, **21 source-file hashes**, and **nine model hashes** passed.

There are two separate reported experiments: four earlier Cervical development runs (20 rounds, seed 42), and nine revised synthetic verification runs (8 rounds, seed 42). They are not a controlled before/after comparison. The earlier secret noise root and reference-prediction arrays were not exported; exact recreation of that trajectory and independent recomputation of its reference AP remain unavailable. The synthetic raw input arrays were omitted, but its generator, configuration, saved models and predictions are retained. The apps do not invent missing state.

The revised engine uses a public-fit partition for preprocessing, warm start and basis construction; separate controller, selection and final test partitions; sparse context queries; a public uniform-prior posterior decoder; a cache with age; projected joint updates; Double-DQN; and a fixed-order client privacy filter. Its adjacency is **replacement of an enrolled client's complete private training/evaluation dataset, conditional on public inputs**. The proposed query uses coordinates 0 and 2 every fifth client visit with a 16-dimensional basis. Named ablations are exposed as controls. A finite conditional accounting bound does not certify the full desktop workflow or exported archive.

## Application adaptation

ContextWeave calls the original train_job, profile_split, allocate_clients, make_bundle, evaluation_gate, evaluate_job and metric routines. The only edit to the vendored v5 numerical file is a progress callback after each completed round. The untouched original is engine/original/v5_original.py. The adapter supplies a named Uploaded schema, canonical labels, metadata and data frame; constructs a fresh custom-data protocol and bundle set; updates derived module globals and the epsilon/rho functions’ default delta; and invokes the original all-model completion gate. It deliberately does not mislabel custom one-dataset/single-seed work as the original four-dataset final inferential protocol. The expensive matched-record repeated histogram Monte Carlo audit is not rerun in custom studies; ordinary final protected histograms and ledgers are retained.

Common adaptations include explicit positive-label selection; uploaded-data schema validation; known source exclusions; numeric/category/age choices; source-compatible mutation and age conversion; user-adjustable experiment grids; persistent independent run folders; isolated worker processes; cancellation; model/seed comparisons; exploratory paired intervals; deterministic sample data; and downloadable experiment records. A raw file is never mistaken for an already-computed result. Reference evidence is read-only and never mixed into new results.

For arbitrary features, bounds may initially be data-derived suggestions. The researcher can edit them. Client allocation and benchmark split construction use labels. These preprocessing and protocol choices are not claimed to be differential privacy releases. CASTLab's separate public-reference assumption and ContextWeave's fixed-schema assumption remain explicit in the guide.

## Interface and deployment scope

Both apps use an original sidebar workspace layout, a restrained ink/ivory palette, one application accent, clear heading hierarchy, accessible labels/focus states, responsive grids, inline data-driven SVG charts and local assets. CSV uploads, settings, execution, evidence and exports are connected to the API. The apps run offline after dependency setup. The application has no remote upload endpoint, CDN, analytics or cloud inference dependency.

This deliverable is an executable **local Python web application**, with Windows and macOS/Linux launchers; it is not a compiled Windows .exe, a public website, or a multi-user authenticated service. Python's loopback HTTP server is deliberately scoped to local use. A public deployment would require a separate authenticated job service, durable storage, resource management and a security review. The original Sites workflow was not used to host the numerical jobs: these applications require a persistent Python CPU runtime and local research-data handling.

## Remaining scientific and operational limits

- Public seeded benchmark noise, exact diagnostics and repeated runs prevent any blanket end-to-end privacy guarantee.
- Different privacy units mean epsilon values from the two apps should not be directly compared as equivalent protections.
- The custom-data interface does not reproduce all original benchmark preprocessing/splits automatically. Paper settings are configurations, not evidence of reproduced scores.
- The full acquisition raw archives are not duplicated into these small application packages. They were inspected and audited; the original four assets remain necessary for reconstructing every saved original artifact.
- The UI does not provide distributed execution, real institution client assignment, patient-group splits, image input, multiclass outcomes, automatic model deployment, or automatic recovery into a partially trained protocol. These would require explicit new protocol choices.
- Statistical intervals are descriptive/exploratory across seeds on a fixed dataset, not clinical generalization claims.
- OS-specific launchers and screenshot-based browser layout verification could not be executed here. See validation records for the checks that were actually performed.

## Primary technical documentation consulted

- https://docs.python.org/3/library/http.server.html — local HTTP server scope.
- https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html — AP definition.
