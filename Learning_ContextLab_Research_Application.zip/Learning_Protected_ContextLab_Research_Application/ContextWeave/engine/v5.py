# DP-CAST-R v5.0: corrected preprocessing, common locked holdout, repeated seeds.
# Execute this ENTIRE file in one Colab/Jupyter cell, or as a standalone .py file.
# Default development run never evaluates held-out test records.
# Candidate contribution, not a claim of algorithmic priority or favourable results.
# PUBLIC BENCHMARKS ONLY. Published seeded noise and exact diagnostics are NOT DP releases.
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import sys, json, math, time, random, hashlib, zipfile, io, urllib.request
import subprocess, importlib.util, itertools, traceback, platform, warnings, ast, gzip, shutil, re
from pathlib import Path
from collections import deque, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
for package,module in [('numpy','numpy'),('pandas','pandas'),('scikit-learn','sklearn'),('scipy','scipy'),('matplotlib','matplotlib')]:
    if importlib.util.find_spec(module) is None:
        subprocess.check_call([sys.executable,'-m','pip','install','-q',package])
import numpy as np
import pandas as pd
import sklearn, scipy
from scipy import stats
from sklearn.metrics import average_precision_score, roc_auc_score, brier_score_loss, f1_score
from sklearn.model_selection import StratifiedGroupKFold, train_test_split
from threadpoolctl import threadpool_limits
_THREAD_LIMITER=threadpool_limits(limits=1)

# -------------------------- EDIT THESE SETTINGS --------------------------
PHASE = os.environ.get('DPCAST_PHASE','development')
# development | preflight | selftest | lock | train | evaluate | analyse | package
# lock downloads/prepares the PUBLIC data and commits the study plan BEFORE training.
# train uses only training+validation bundles. evaluate refuses an incomplete study.
STUDY_DIR = Path(os.environ.get('DPCAST_STUDY','/content/dp_cast_v5_study' if Path('/content').exists() else 'dp_cast_v5_study'))
DEVELOPMENT_DIR = Path(os.environ.get('DPCAST_DEV','/content/dp_cast_v5_development' if Path('/content').exists() else 'dp_cast_v5_development'))
LOCAL_CSV = json.loads(os.environ.get('DPCAST_LOCAL_CSV','{}'))
# Example: {'Cervical_Cancer':'/content/risk_factors_cervical_cancer.csv'}
AUTO_DOWNLOAD = os.environ.get('DPCAST_DOWNLOAD','1')=='1'
DATA_CACHE = Path(os.environ.get('DPCAST_DATA_CACHE','/content/dp_cast_public_data' if Path('/content').exists() else 'dp_cast_public_data'))
SHARD_COUNT = int(os.environ.get('DPCAST_SHARDS','1'))
SHARD_INDEX = int(os.environ.get('DPCAST_SHARD_INDEX','0'))
PROFILE = os.environ.get('DPCAST_PROFILE','core')
C = {
 'datasets':['Cervical_Cancer','CDC_Diabetes','Glioma_Grading','SUPPORT2'],
 'minimum_datasets':4, # both standard modes must retain all four benchmarks
 'splitter':'fixed_holdout_profile_v2', 'holdout_seed':842019,
 'study_profile':PROFILE,
 'require_original_row_counts':True,
 'seeds':[142,152,162,172,182,192,202,212,222,232],
 'alphas':[0.5], 'epsilons':[16.], 'rounds':60,
 'clients':8, 'participation':0.75, 'delta':1e-5,
 'encoder':[32,16], 'head':16, 'lr':0.05, 'head_lr':0.05,
 'local_steps':1, 'memory_chunk':256, 'dropout':0.10, 'blend':0.20,
 'base_clip':1., 'focal_alpha':0.75, 'focal_gamma':2.,
 'context_fraction':0.15, 'clip_fraction':0.05, 'evaluation_fraction':0.10,
 'feedback':'brier', 'feedback_bins':20, 'evaluation_bins':30,
 'noise_mode':'benchmark', # benchmark | secure; neither mode certifies private deployment
 'main_methods':['non_private','fixed_dp','adaptive_clip','rule','random','frozen',
                 'learned','gate_frozen','gate_learned'],
 'focused_ablations':True, 'ablation_alpha':0.5, 'ablation_epsilon':16.,
 'acquisition_ablations':['gate_periodic','gate_random','gate_no_recycle','gate_constant','gate_noise_only'],
 'periodic_every':2, 'random_query_probability':0.5,
 'context_price_grid':[0.05,0.15,0.30],
 'audit_bins':[10,30,60], 'audit_multipliers':[0.25,1.,4.], 'audit_repeats':30,
 'bootstrap_repeats':10000, 'practical_ap_margin':0.005,
 'checkpoint_every':5, 'learning_batch':32, 'replay_capacity':5000,
 'discount':0.95, 'q_lr':0.001, 'target_every':20,
 'exploration_start':0.50, 'exploration_end':0.05,
 'previous_test_exposure':True, 'external_cohort':False,
 'profile_group_split':True, # same encoded feature profiles cannot cross splits
 'save_common_predictions':True,
 'strict_environment':True,
 'development_seed':42, 'development_rounds':30,
}
if PROFILE=='extended':
    C['alphas']=[0.1,0.5,1.0];C['epsilons']=[8.,16.,32.]
elif PROFILE!='core':
    raise ValueError('DPCAST_PROFILE must be core or extended; use a separate study directory for each.')
# No row cap is applied to any locked study. To change scope, change C BEFORE lock.
# ------------------------------------------------------------------------
VERSION='dpcast-r-5.0'
K=C['clients']; DELTA=C['delta']; BATCH_CHUNK=C['memory_chunk']; BASE_CLIP=C['base_clip']
DROPOUT=C['dropout']; FOCAL_ALPHA=C['focal_alpha']; FOCAL_GAMMA=C['focal_gamma']
ACTIONS=[(c,a) for c in (.75,1.,1.25) for a in (.55,.65,.75,.85,.95)]
FIXED_ACTION=ACTIONS.index((1.,.75))
OPERATIONAL_NAMES={'PHASE','STUDY_DIR','DEVELOPMENT_DIR','LOCAL_CSV','AUTO_DOWNLOAD','SHARD_COUNT','SHARD_INDEX','DATA_CACHE'}

DATASETS={

 'CDC_Diabetes':{

  'id':891,'url':'https://www.kaggle.com/datasets/alexteboul/diabetes-health-indicators-dataset',

  'target':'Diabetes_binary','positive':1,'drop':['ID'],

  'allow':None,'bounds':{'BMI':(0,100),'Age':(1,13),'Education':(1,6),'Income':(1,8),

                            'MentHlth':(0,30),'PhysHlth':(0,30),'GenHlth':(1,5)}},

 'Cervical_Cancer':{

  'id':383,'url':'https://archive.ics.uci.edu/dataset/383/cervical+cancer+risk+factors',

  'target':'Biopsy','positive':1,

  'drop':['Hinselmann','Schiller','Cytology','Dx:Cancer','Dx:CIN','Dx:HPV','Dx'],

  'allow':None,'bounds':{'Age':(0,100),'Number of sexual partners':(0,100),

      'First sexual intercourse':(0,100),'Num of pregnancies':(0,30),

      'Smokes (years)':(0,100),'Smokes (packs/year)':(0,500),

      'Hormonal Contraceptives (years)':(0,100),'IUD (years)':(0,100),

      'STDs (number)':(0,100),'STDs: Number of diagnosis':(0,100),

      'STDs: Time since first diagnosis':(0,100),'STDs: Time since last diagnosis':(0,100)}},

 'Glioma_Grading':{

  'id':759,'url':'https://archive.ics.uci.edu/dataset/759/glioma+grading+clinical+and+mutation+features+dataset',

  'target':'Grade','positive':'GBM','drop':['Case_ID','Project','Primary_Diagnosis'],

  'allow':None,'bounds':{'Age_at_diagnosis':(0,120),'Gender':(0,1),'Race':(0,4)}},

 'SUPPORT2':{

  'id':880,'url':'https://hbiostat.org/data/repo/support2csv.zip',

  'target':'hospdead','positive':1,

  'drop':['id','death','slos','d.time','sfdm2','charges','totcst','totmcst','avtisst',

          'surv2m','surv6m','prg2m','prg6m'],

  'allow':['age','sex','dzgroup','dzclass','num.co','edu','income','race',

           'hday','diabetes','dementia','ca'],

  'bounds':{'age':(0,120),'num.co':(0,50),'edu':(0,30),'hday':(0,1000),

            'diabetes':(0,1),'dementia':(0,1)}},

}
# Fixed schemas; never infer numeric/categorical types from private records.
DATASETS['Glioma_Grading']['categorical'] = ['Gender','Race']
DATASETS['SUPPORT2']['categorical'] = ['sex','dzgroup','dzclass','income','race','ca']
DATASETS['CDC_Diabetes']['columns'] = ['HighBP','HighChol','CholCheck','BMI','Smoker','Stroke',
 'HeartDiseaseorAttack','PhysActivity','Fruits','Veggies','HvyAlcoholConsump','AnyHealthcare',
 'NoDocbcCost','GenHlth','MentHlth','PhysHlth','DiffWalk','Sex','Age','Education','Income']
DATASETS['Glioma_Grading']['columns'] = ['Gender','Age_at_diagnosis','Race','IDH1','TP53','ATRX',
 'PTEN','EGFR','CIC','MUC16','PIK3CA','NF1','PIK3R1','FUBP1','RB1','NOTCH1','BCOR','CSMD3',
 'SMARCA4','GRIN2A','IDH2','FAT4','PDGFRA']
DATASETS['Cervical_Cancer']['columns'] = ['Age','Number of sexual partners','First sexual intercourse',
 'Num of pregnancies','Smokes','Smokes (years)','Smokes (packs/year)','Hormonal Contraceptives',
 'Hormonal Contraceptives (years)','IUD','IUD (years)','STDs','STDs (number)',
 'STDs:condylomatosis','STDs:cervical condylomatosis','STDs:vaginal condylomatosis',
 'STDs:vulvo-perineal condylomatosis','STDs:syphilis','STDs:pelvic inflammatory disease',
 'STDs:genital herpes','STDs:molluscum contagiosum','STDs:AIDS','STDs:HIV',
 'STDs:Hepatitis B','STDs:HPV','STDs: Number of diagnosis',
 'STDs: Time since first diagnosis','STDs: Time since last diagnosis']
DATASETS['SUPPORT2']['columns'] = DATASETS['SUPPORT2']['allow']
# Source-specific outcome definitions; the CDC binary file maps three-class label 1
# (prediabetes) to 0, and three-class label 2 (diabetes) to 1. See label audit.
DATASET_DETAILS={
 'Cervical_Cancer':dict(title='Cervical Cancer Risk Factors',expected_rows=858,
   task='Biopsy-positive cervical cancer indicator',positive_label='Biopsy = 1',negative_label='Biopsy = 0'),
 'CDC_Diabetes':dict(title='CDC BRFSS 2015 Diabetes Health Indicators',expected_rows=253680,
   task='Diabetes versus no diabetes/prediabetes in the selected binary CSV',positive_label='Diabetes_binary = 1 (diabetes)',negative_label='Diabetes_binary = 0 (no diabetes or prediabetes)'),
 'Glioma_Grading':dict(title='Glioma Grading Clinical and Mutation Features',expected_rows=862,
   task='GBM versus lower-grade glioma using tabular clinical/mutation features',positive_label='GBM / Grade = 1',negative_label='LGG / Grade = 0'),
 'SUPPORT2':dict(title='SUPPORT2 Seriously Ill Hospitalised Adults',expected_rows=9105,
   task='In-hospital mortality; no prospective 24-hour claim',positive_label='hospdead = 1',negative_label='hospdead = 0'),
}
SOURCE_URLS={
 'CDC_Diabetes':'https://www.kaggle.com/api/v1/datasets/download/alexteboul/diabetes-health-indicators-dataset',
 'Cervical_Cancer':'https://archive.ics.uci.edu/static/public/383/cervical%2Bcancer%2Brisk%2Bfactors.zip',
 'Glioma_Grading':'https://archive.ics.uci.edu/static/public/759/glioma%2Bgrading%2Bclinical%2Band%2Bmutation%2Bfeatures%2Bdataset.zip',
 'SUPPORT2':'https://hbiostat.org/data/repo/support2csv.zip',
}


def jsonable(v):
    if isinstance(v, dict): return {str(k):jsonable(x) for k,x in v.items()}
    if isinstance(v, (tuple,list)): return [jsonable(x) for x in v]
    if isinstance(v, np.ndarray): return jsonable(v.tolist())
    if isinstance(v, np.generic): return jsonable(v.item())
    if isinstance(v, float) and not math.isfinite(v): return None
    if isinstance(v, Path): return str(v)
    return v

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(jsonable(value), indent=2, allow_nan=False))
    temp.replace(path)

def stable_seed(*items):
    return int(hashlib.sha256('|'.join(map(str,items)).encode()).hexdigest()[:8],16)

class Noise:
    """OS-entropy normals; no noise seeds/states persisted. Not a certified DP sampler."""
    def __init__(self): self.rng=random.SystemRandom()
    def normal(self, sd, shape):
        assert sd>0 and math.isfinite(sd)
        return np.fromiter((self.rng.normalvariate(0.,sd) for _ in range(int(np.prod(shape)))),
                           dtype=np.float64).reshape(shape)

class BenchmarkNoise:
    """Deterministic PUBLIC-data simulation; published seed invalidates release DP."""
    def __init__(self,seed): self.rng=np.random.default_rng(seed)
    def normal(self,sd,shape): return self.rng.normal(0.,sd,shape)


def rho_to_eps(rho, delta=DELTA):
    if rho<=0: return 0.
    return float(rho+2*math.sqrt(rho*math.log(1/delta)))

def eps_to_rho(eps, delta=DELTA):
    assert eps>0 and 0<delta<1
    L=math.log(1/delta)
    return float((eps/(math.sqrt(L+eps)+math.sqrt(L)))**2)

@dataclass
class Ledger:
    cap: float
    rho: float=0.
    events: list=field(default_factory=list)
    def can(self, costs): return self.rho+sum(costs)<=self.cap+1e-12
    def spend(self, kind, cost, **meta):
        if cost<=0 or not self.can([cost]): raise RuntimeError('Budget release blocked: '+kind)
        self.rho+=cost
        self.events.append(dict(kind=kind,rho=cost,cumulative_rho=self.rho,
                                epsilon=rho_to_eps(self.rho),**meta))

def release(value, sensitivity, rho, noise):
    if rho<=0 or sensitivity<=0: raise ValueError('Positive rho/sensitivity required')
    a=np.asarray(value,dtype=float)
    return a+noise.normal(sensitivity/math.sqrt(2*rho),a.shape)

def download(url):
    error=None
    for attempt in range(3):
        try:
            req=urllib.request.Request(url, headers={'User-Agent':'DPCAST-research/4.0'})
            with urllib.request.urlopen(req,timeout=45) as response: return response.read()
        except Exception as e:
            error=e
            if attempt<2: time.sleep(2**attempt)
    raise RuntimeError(f'Download failed: {url}: {error}')

_FRAME_CACHE={}
_SOURCE_BYTES={}
_ENCODED_CACHE={}
_SPLIT_CACHE={}
_TRANSFORM_REPORTS={}
EXPECTED_SOURCE_HASHES={
 'Cervical_Cancer':'8df193ad5c9ff4288fb4c401eef70dcd2cbda404ce7f82ac74c68cfc960ab063',
 'CDC_Diabetes':'19f367e3e3350768f0c144c5d73ee5b355f67a57eaaa86ca7bd8aec594d8b1d0',
 'Glioma_Grading':'6c617f370467b99e3d9b17633ac735fb900801fd6ffc8cc865344067e84b6312',
 'SUPPORT2':'79621945edf2a5c8dc36359684ff356d3c6025e773ba4fefac26f865f7894c78'}
def get_frame(name):
    if name in _FRAME_CACHE:return _FRAME_CACHE[name]
    spec=DATASETS[name];source=SOURCE_URLS[name]
    csv_path=DATA_CACHE/(name+'.csv');meta_path=DATA_CACHE/(name+'.json')
    if name in LOCAL_CSV:
        data=Path(LOCAL_CSV[name]).read_bytes();source=str(Path(LOCAL_CSV[name]).resolve())
    elif csv_path.exists() and meta_path.exists():
        metadata=json.loads(meta_path.read_text());data=csv_path.read_bytes()
        if hashlib.sha256(data).hexdigest()!=metadata['sha256']:raise RuntimeError('Cached source hash mismatch: '+name)
        if metadata['origin_url']!=source:raise RuntimeError('Cached source origin mismatch: '+name)
    else:
        print('DOWNLOAD',name,flush=True);raw=download(source)
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                candidates=[q for q in z.namelist() if q.lower().endswith('.csv') and not q.startswith('__MACOSX')]
                filenames={'CDC_Diabetes':'diabetes_binary_health_indicators_BRFSS2015.csv',
                           'Cervical_Cancer':'risk_factors_cervical_cancer.csv',
                           'Glioma_Grading':'TCGA_GBM_LGG_Mutations_all.csv'}
                if name in filenames:candidates=[q for q in candidates if Path(q).name==filenames[name]]
                if len(candidates)!=1:raise ValueError(f'{name}: cannot uniquely select CSV: {candidates}')
                data=z.read(candidates[0])
                # Verify the selected diabetes endpoint directly, rather than relying
                # on inconsistent secondary descriptions of this binary CSV.
                if name=='CDC_Diabetes':
                    tri_files=[q for q in z.namelist() if Path(q).name=='diabetes_012_health_indicators_BRFSS2015.csv']
                    if len(tri_files)!=1:raise ValueError('Missing paired three-class CSV for diabetes label audit')
                    binary=pd.read_csv(io.BytesIO(data));tri=pd.read_csv(z.open(tri_files[0]))
                    if not binary.drop(columns='Diabetes_binary').equals(tri.drop(columns='Diabetes_012')):
                        raise ValueError('Diabetes files have different records/order; cannot verify target mapping')
                    if not np.array_equal(binary.Diabetes_binary.to_numpy(),(tri.Diabetes_012==2).to_numpy(int)):
                        raise ValueError('Diabetes target mapping changed; review the protocol')
        except zipfile.BadZipFile as e:
            raise RuntimeError(f'{name}: source returned a non-ZIP response. Supply the ORIGINAL CSV with LOCAL_CSV; no dataset will be skipped.') from e
    if hashlib.sha256(data).hexdigest()!=EXPECTED_SOURCE_HASHES[name]:
        raise ValueError(name+': source bytes differ from the reviewed original source. Review and version a new protocol; do not silently substitute data.')
    frame=pd.read_csv(io.BytesIO(data),na_values=['?','--','not reported'],low_memory=False)
    frame.columns=frame.columns.astype(str).str.strip()
    required=set(spec['columns'])|{spec['target']}
    if required-set(frame):raise ValueError(f'{name}: missing columns {sorted(required-set(frame))}')
    if C['require_original_row_counts'] and len(frame)!=DATASET_DETAILS[name]['expected_rows']:
        raise ValueError(f'{name}: expected {DATASET_DETAILS[name]["expected_rows"]} original rows, got {len(frame)}. A balanced/subsampled CSV is a different protocol.')
    labels=encode_labels(frame[spec['target']],name)
    if len(np.unique(labels))!=2:raise ValueError(name+': source must contain both outcome classes')
    meta=dict(source=source,source_sha256=hashlib.sha256(data).hexdigest(),rows=len(frame),
              target=spec['target'],**DATASET_DETAILS[name])
    if name not in LOCAL_CSV:
        DATA_CACHE.mkdir(parents=True,exist_ok=True)
        tmp=csv_path.with_suffix('.csv.tmp');tmp.write_bytes(data);tmp.replace(csv_path)
        write_json(meta_path,dict(origin_url=source,sha256=meta['source_sha256']))
    _SOURCE_BYTES[name]=data;_FRAME_CACHE[name]=(frame,meta)
    return frame,meta


def encode_labels(s, name):
    if name=='Glioma_Grading':
        text=s.astype(str).str.strip().str.upper()
        if set(text)<= {'LGG','GBM'}: return (text=='GBM').to_numpy(dtype=int)
    y=pd.to_numeric(s, errors='coerce')
    if y.isna().any() or not set(y.unique())<={0,1}: raise ValueError(f'{name}: expected binary0/1 labels')
    return y.to_numpy(dtype=int)

def parse_age(value):
    """Years plus optional days; missing stays missing, malformed data fails closed."""
    if pd.isna(value):return np.nan
    text=str(value).strip().lower()
    if text in ('','?','--','not reported'):return np.nan
    match=re.fullmatch(r'(\d+(?:\.\d+)?)\s*years?(?:\s+(\d+(?:\.\d+)?)\s*days?)?',text)
    if match:
        years=float(match[1]);days=float(match[2] or 0)
        if days>=366:raise ValueError('Invalid age day remainder: '+text)
        age=years+days/365.25
    else:
        try:age=float(text)
        except ValueError as exc:raise ValueError('Unrecognised age: '+text) from exc
    if not math.isfinite(age) or not 0<=age<=120:raise ValueError('Invalid age range: '+text)
    return age

def transform(frame, name):
    spec=DATASETS[name]; arr=[];report=[]
    for col in spec['columns']:
        if col in spec.get('categorical',[]):
            vals=frame[col].fillna('__missing__').astype(str)
            bucket=np.array([stable_seed(col,x)%8 for x in vals])
            arr.extend([(bucket==b).astype(float) for b in range(8)])
            report.append(dict(feature=col,kind='fixed_hash_categorical',missing=int(frame[col].isna().sum()),
              raw_unique=int(vals.nunique()),occupied_buckets=int(len(np.unique(bucket))),
              hash_collisions=int(vals.nunique()-len(np.unique(bucket)))))
        else:
            mapping={'MUTATED':1,'NOT_MUTATED':0,'Male':0,'Female':1}
            raw=frame[col].map(lambda v: mapping.get(v,v))
            if name=='Glioma_Grading' and col=='Age_at_diagnosis':v=raw.map(parse_age)
            else:
                v=pd.to_numeric(raw,errors='coerce')
                bad=raw.notna()&v.isna()
                if bad.any():raise ValueError(f'{name}/{col}: numeric parsing lost {int(bad.sum())} nonmissing values')
            if np.isinf(v.to_numpy(float)).any():raise ValueError(f'{name}/{col}: infinite numeric value')
            # For mutation/indicator variables schema bounds default0/1, fixed in advance.
            lo,hi=spec['bounds'].get(col,(0,1))
            encoded=np.clip((v.fillna(lo).to_numpy()-lo)/(hi-lo),0,1)
            report.append(dict(feature=col,kind='fixed_bound_numeric',original_missing=int(raw.isna().sum()),
              parsed_missing=int(v.isna().sum()),nonmissing_unique=int(v.nunique()),
              below_bound=int((v<lo).sum()),above_bound=int((v>hi).sum()),
              encoded_value_column=len(arr),encoded_variance=float(np.var(encoded)),minimum=float(v.min()) if v.notna().any() else None,
              maximum=float(v.max()) if v.notna().any() else None))
            if raw.notna().any() and not v.notna().any():raise ValueError(f'{name}/{col}: entire feature lost')
            if name=='Glioma_Grading' and col=='Age_at_diagnosis':
                if v.nunique()<2 or v.isna().sum()!=raw.isna().sum():raise ValueError('Age information was not preserved')
            arr.extend([encoded,v.isna().to_numpy(float)])
    _TRANSFORM_REPORTS[name]=dict(dataset=name,age_day_divisor=365.25 if name=='Glioma_Grading' else None,features=report)
    result=np.stack(arr,axis=1).astype(np.float64)
    if not np.isfinite(result).all():raise ValueError('Non-finite encoded matrix')
    return result

# Per-example neural gradients: clipping norm computed without allocating N*P Jacobian.
def init_layers(sizes,rng):
    return [[rng.normal(0,math.sqrt(2/a),(a,b)),np.zeros(b)] for a,b in zip(sizes[:-1],sizes[1:])]
def copy_layers(layers): return [[w.copy(),b.copy()] for w,b in layers]
def flatten_layers(layers): return np.concatenate([v.ravel() for layer in layers for v in layer])
def assign_vector(vector, reference):
    layers=[]; offset=0
    for layer in reference:
        out=[]
        for a in layer:
            out.append(vector[offset:offset+a.size].reshape(a.shape).copy()); offset+=a.size
        layers.append(out)
    assert offset==len(vector)
    return layers

def forward(X,layers,dropout=0.,rng=None):
    a=X; cache=[]
    for j,(w,b) in enumerate(layers):
        z=a@w+b
        if j<len(layers)-1:
            mask=(z>0).astype(float)
            if dropout: mask*= (rng.random(z.shape)>=dropout)/(1-dropout)
            nxt=z*mask
        else: mask=None; nxt=z
        cache.append((a,z,mask)); a=nxt
    logits=np.clip(a[:,0],-30,30)
    return 1/(1+np.exp(-logits)),cache

def focal_loss_and_derivative(p,y):
    p=np.clip(p,1e-12,1-1e-12); pt=np.where(y==1,p,1-p)
    a=np.where(y==1,FOCAL_ALPHA,1-FOCAL_ALPHA)
    loss=-a*(1-pt)**FOCAL_GAMMA*np.log(pt)
    term=FOCAL_GAMMA*(1-pt)**(FOCAL_GAMMA-1)*np.log(pt)-(1-pt)**FOCAL_GAMMA/pt
    derivative=a*term*np.where(y==1,1.,-1.)*p*(1-p)
    return loss,derivative

def per_example_backprop(X,y,layers,dropout=0.,rng=None):
    p,cache=forward(X,layers,dropout,rng)
    loss,d=focal_loss_and_derivative(p,y); d=d[:,None]; ds=[None]*len(layers)
    norm2=np.zeros(len(X))
    for j in range(len(layers)-1,-1,-1):
        ds[j]=d
        a=cache[j][0]
        norm2+=(np.sum(a*a,axis=1)+1)*np.sum(d*d,axis=1)
        if j: d=(d@layers[j][0].T)*cache[j-1][2]
    return p,cache,ds,np.sqrt(norm2),loss

def clipped_mean_gradient(X,y,layers,clip,drop_rng=None):
    accum=[[np.zeros_like(w),np.zeros_like(b)] for w,b in layers]
    for start in range(0,len(y),BATCH_CHUNK):
        sl=slice(start,start+BATCH_CHUNK)
        p,cache,ds,norm,loss=per_example_backprop(X[sl],y[sl],layers,
                                                DROPOUT if drop_rng is not None else 0.,drop_rng)
        factor=np.minimum(1.,clip/np.maximum(norm,1e-15))
        for j,d in enumerate(ds):
            weighted=d*factor[:,None]
            accum[j][0]+=cache[j][0].T@weighted
            accum[j][1]+=weighted.sum(axis=0)
    return flatten_layers(accum)/len(y)

def context_values(X,y,layers,previous):
    sums=np.zeros(5); flag=0.
    for start in range(0,len(y),BATCH_CHUNK):
        xx=X[start:start+BATCH_CHUNK]; yy=y[start:start+BATCH_CHUNK]
        p,cache,ds,norm,loss=per_example_backprop(xx,yy,layers)
        _,old=forward(xx,previous)
        # bounded per-row representation change; no cross-client raw statistic.
        change=np.minimum(1.,np.linalg.norm(cache[2][0]-old[2][0],axis=1)/math.sqrt(cache[2][0].shape[1]))
        vals=np.stack([abs(p-yy),4*p*(1-p),yy,change,(p>=.5).astype(float)],axis=1)
        sums+=vals.sum(axis=0); flag+=np.sum(norm<=BASE_CLIP)
    return sums/len(y),flag/len(y)

def predict(X,layers):
    return np.concatenate([forward(X[i:i+BATCH_CHUNK],layers)[0] for i in range(0,len(X),BATCH_CHUNK)])

def histogram_metrics(hist):
    h=np.maximum(hist,0); neg,pos=h; P=pos.sum(); N=neg.sum()
    tp=np.cumsum(pos[::-1]); fp=np.cumsum(neg[::-1]); precision=tp/np.maximum(tp+fp,1e-15)
    ap=float(np.sum(pos[::-1]*precision)/P) if P>0 else None
    # Pairwise AUC, half credit for scores in same bin.
    auc=float(np.sum(pos*(np.cumsum(neg)-.5*neg))/(P*N)) if P>0 and N>0 else None
    return dict(hist_ap=ap,hist_auroc=auc,hist_recall=float(pos[h.shape[1]//2:].sum()/P) if P>0 else None,
                hist_specificity=float(neg[:h.shape[1]//2].sum()/N) if N>0 else None)


# ----------------------- provenance and locked data -----------------------
def canonical(value):
    return json.dumps(jsonable(value),sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(value): return hashlib.sha256(canonical(value).encode()).hexdigest()
def file_hash(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()
def source_capture():
    candidate=None
    if '__file__' in globals() and Path(__file__).is_file(): candidate=Path(__file__).read_text()
    if candidate is None or 'def source_capture()' not in candidate:
        try: candidate=get_ipython().history_manager.input_hist_raw[-1]
        except Exception as e: raise RuntimeError('Execute the complete supplied file or its single notebook cell.') from e
    if VERSION not in candidate or 'def main()' not in candidate:
        raise RuntimeError('Incomplete source capture; execute the entire supplied code in one cell.')
    compile(candidate,'executed_source.py','exec')
    tree=ast.parse(candidate)
    tree.body=[node for node in tree.body if not (isinstance(node,ast.Assign) and
               any(isinstance(t,ast.Name) and t.id in OPERATIONAL_NAMES for t in node.targets))]
    return candidate,hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()
def environment():
    return dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,
                sklearn=sklearn.__version__,scipy=scipy.__version__)
def record_invocation(root,phase):
    source,implementation=source_capture()
    folder=root/'provenance'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    folder.mkdir(parents=True,exist_ok=False)
    (folder/'executed_source.py').write_text(source)
    meta=dict(phase=phase,utc=datetime.now(timezone.utc).isoformat(),
              source_sha256=file_hash(folder/'executed_source.py'),implementation_sha256=implementation,
              environment=environment(),platform=platform.platform(),configuration=C)
    write_json(folder/'invocation.json',meta)
    (folder/'pip_freeze.txt').write_text(subprocess.run([sys.executable,'-m','pip','freeze'],capture_output=True,text=True).stdout)
    return meta

def validate_config():
    if C['noise_mode'] not in ('benchmark','secure'): raise ValueError('Unknown noise mode')
    if len(C['encoder'])!=2: raise ValueError('This implementation uses exactly two encoder layers')
    if C['feedback'] not in ('brier','absolute','hist_ap'): raise ValueError('Unknown feedback query')
    if not 0<C['participation']<=1: raise ValueError('Participation must be in (0,1]')
    if not 0<C['evaluation_fraction']<1: raise ValueError('Invalid evaluation reserve')
    if any(not 0<f<1-C['clip_fraction'] for f in C['context_price_grid']+[C['context_fraction']]):
        raise ValueError('Invalid context allocation')
    if not 0<=SHARD_INDEX<SHARD_COUNT: raise ValueError('Invalid shard assignment')
    if len(set(C['seeds']))!=len(C['seeds']): raise ValueError('Repeated seeds')
    if len(C['seeds'])<2:raise ValueError('The final inferential protocol requires at least two independent seeds; ten is the default')
    for key in ['datasets','alphas','epsilons','main_methods']:
        if not C[key] or len(set(C[key]))!=len(C[key]):raise ValueError('Empty or repeated settings: '+key)
    if not set(C['datasets'])<=set(DATASETS):raise ValueError('Unknown dataset')
    if len(C['datasets'])<C['minimum_datasets']:raise ValueError('Both standard modes require at least four configured datasets')
    if C['splitter']!='fixed_holdout_profile_v2':raise ValueError('Unknown splitter')
    if not C['profile_group_split']:raise ValueError('The fixed common holdout requires intact feature-profile groups')
    if C['periodic_every']<1 or not 0<C['random_query_probability']<1:raise ValueError('Invalid acquisition schedule')
    if C['development_seed'] in C['seeds']:raise ValueError('Development seed overlaps final training seeds')
    if not set(C['acquisition_ablations'])<= {'gate_periodic','gate_random','gate_no_recycle','gate_constant','gate_noise_only'}:
        raise ValueError('Unknown acquisition ablation')
    if not 0<C['clip_fraction']<1:raise ValueError('Clipping cost must be positive')
    if not 0<C['delta']<1 or any(x<=0 for x in C['alphas']+C['epsilons']):raise ValueError('Invalid privacy or heterogeneity setting')
    if C['learning_batch']>C['replay_capacity'] or C['learning_batch']<1:raise ValueError('Replay cannot supply the learning batch')
    if C['local_steps']<1 or C['checkpoint_every']<1:raise ValueError('Steps/checkpoint interval must be positive')
    if any(b<2 or b%2 for b in [C['feedback_bins'],C['evaluation_bins']]+C['audit_bins']):
        raise ValueError('Use positive EVEN bin counts so the 0.5 classification threshold is an exact bin edge')
    if C['focused_ablations'] and (C['ablation_alpha'] not in C['alphas'] or C['ablation_epsilon'] not in C['epsilons']):
        raise ValueError('The ablation anchor must occur in the main grid')
    if C['rounds']<10: raise ValueError('Use at least ten rounds; learning adequacy is assessed separately')

@dataclass
class TrainingData:
    X: np.ndarray
    y: np.ndarray
    V: np.ndarray
    v: np.ndarray
    clients: list
    validation_clients: list
    bundle_hash: str


def profile_split(X,y,seed):
    """One fixed public holdout across ALL seeds; train/validation vary within the rest.

    This is a procedural evaluation lock, not a secret vault or external cohort.
    Label-dependent group stratification remains outside the conditional DP claim.
    """
    ids=np.arange(len(y))
    profiles=pd.util.hash_pandas_object(pd.DataFrame(X),index=False).to_numpy()
    unique,inverse,counts=np.unique(profiles,return_inverse=True,return_counts=True)
    positives=np.bincount(inverse,weights=y,minlength=len(unique))
    strata=np.where(positives==0,0,np.where(positives==counts,11,1+np.floor(10*positives/counts))).astype(int)
    assignment=np.zeros(len(unique),dtype=np.int8)
    holdout_rng=np.random.default_rng(C['holdout_seed']);training_rng=np.random.default_rng(seed)
    for label in np.unique(strata):
        groups=holdout_rng.permutation(np.flatnonzero(strata==label));mass=counts[groups]
        midpoints=(np.cumsum(mass)-.5*mass)/mass.sum()
        assignment[groups[midpoints>=.8]]=2
        remaining=training_rng.permutation(groups[midpoints<.8])
        if len(remaining):
            mass=counts[remaining];midpoints=(np.cumsum(mass)-.5*mass)/mass.sum()
            assignment[remaining[midpoints>=.75]]=1
    row_assignment=assignment[inverse]
    train,valid,test=(ids[row_assignment==j] for j in range(3))
    for a,b in ((train,valid),(train,test),(valid,test)):
        if np.intersect1d(profiles[a],profiles[b]).size:raise AssertionError('Feature-profile split leakage')
    for part in (train,valid,test):
        if len(np.unique(y[part]))!=2:raise ValueError('Split lacks a class. Revise the protocol; do not silently resplit.')
    joined=np.concatenate([train,valid,test])
    if len(joined)!=len(y) or not np.array_equal(np.sort(joined),ids):raise AssertionError('Invalid/disjoint split cover')
    return train,valid,test


def dataset_preflight(root):
    """Validate EVERY requested source before starting any training job."""
    validate_config();root.mkdir(parents=True,exist_ok=True);rows=[];errors=[]
    for name in C['datasets']:
        started=time.perf_counter()
        try:
            frame,meta=get_frame(name)
            if name not in _ENCODED_CACHE:_ENCODED_CACHE[name]=(transform(frame,name),encode_labels(frame[DATASETS[name]['target']],name))
            X,y=_ENCODED_CACHE[name]
            if not np.isfinite(X).all():raise ValueError('Non-finite encoded features')
            tr,va,te=profile_split(X,y,C['development_seed'])
            _SPLIT_CACHE[(name,C['development_seed'])]=(tr,va,te)
            row=dict(dataset=name,rows=len(y),positives=int(y.sum()),prevalence=float(y.mean()),features=X.shape[1],
               source_sha256=meta['source_sha256'],target=meta['target'],task=meta['task'],
               positive_label=meta['positive_label'],negative_label=meta['negative_label'],
               train_n=len(tr),validation_n=len(va),test_n=len(te),
               train_positive=int(y[tr].sum()),validation_positive=int(y[va].sum()),test_positive=int(y[te].sum()),
               split_seed=C['development_seed'],splitter=C['splitter'],passed=True,seconds=time.perf_counter()-started)
            rows.append(row);print('DATA READY',name,'n=',len(y),'positive=',int(y.sum()),'features=',X.shape[1],flush=True)
            write_json(root/(name+'_feature_audit.json'),_TRANSFORM_REPORTS[name])
        except Exception as e:
            errors.append(dict(dataset=name,error=str(e)));print('DATA FAILED',name,str(e),flush=True)
    report=dict(version=VERSION,requested=C['datasets'],passed=not errors and len(rows)==len(C['datasets']),datasets=rows,errors=errors)
    write_json(root/'dataset_preflight.json',report);pd.DataFrame(rows).to_csv(root/'dataset_inventory.csv',index=False)
    if errors:raise RuntimeError('Dataset preflight failed. No training started. Read dataset_preflight.json and provide the original CSVs if needed.')
    return report


def allocate_clients(y,proportions,seed,minimum=2):
    rng=np.random.default_rng(seed)
    if len(y)<K*minimum: raise ValueError('Not enough records for client floor')
    indices=rng.permutation(len(y)); groups=[indices[i*minimum:(i+1)*minimum].tolist() for i in range(K)]
    rest=indices[K*minimum:]
    for label in (0,1):
        rows=rest[y[rest]==label]; rng.shuffle(rows)
        counts=rng.multinomial(len(rows),proportions[label])
        for i,part in enumerate(np.split(rows,np.cumsum(counts)[:-1])): groups[i].extend(part.tolist())
    return [np.asarray(a,dtype=int) for a in groups]


def block_id(dataset,seed,alpha): return digest([dataset,int(seed),float(alpha)])[:18]
def make_bundle(root,dataset,seed,alpha):
    folder=root/'bundles'/block_id(dataset,seed,alpha); folder.mkdir(parents=True,exist_ok=True)
    frame,meta=get_frame(dataset)
    if frame[DATASETS[dataset]['target']].isna().any():
        raise ValueError(dataset+': missing outcomes. No silent outcome exclusion permitted.')
    if dataset not in _ENCODED_CACHE:
        _ENCODED_CACHE[dataset]=(transform(frame,dataset),encode_labels(frame[DATASETS[dataset]['target']],dataset))
    X,y=_ENCODED_CACHE[dataset]
    if not np.isfinite(X).all(): raise ValueError('Non-finite features')
    if (dataset,seed) not in _SPLIT_CACHE:_SPLIT_CACHE[(dataset,seed)]=profile_split(X,y,seed)
    tr,va,te=_SPLIT_CACHE[(dataset,seed)]
    proportions=np.random.default_rng(stable_seed(seed,alpha,'client-proportions')).dirichlet(np.full(K,alpha),size=2)
    parts=[allocate_clients(y[ix],proportions,stable_seed(seed,alpha,j)) for j,ix in enumerate((tr,va,te))]
    np.savez_compressed(folder/'training_validation.npz',X=X[tr],y=y[tr],V=X[va],v=y[va],
                        **{f'train_{i}':parts[0][i] for i in range(K)},
                        **{f'valid_{i}':parts[1][i] for i in range(K)})
    np.savez_compressed(folder/'heldout_test.npz',X=X[te],y=y[te],**{f'client_{i}':parts[2][i] for i in range(K)})
    np.savez_compressed(folder/'split_indices.npz',train=tr,validation=va,test=te)
    support=[]
    for split,idx,groups in zip(['training','validation','test'],[tr,va,te],parts):
        for i,group in enumerate(groups):
            support.append(dict(split=split,client=i,n=len(group),positive=int(y[idx[group]].sum())))
    pd.DataFrame(support).to_csv(folder/'support_PUBLIC_ONLY.csv',index=False)
    result=dict(dataset=dataset,seed=seed,alpha=alpha,source=meta,features=X.shape[1],
                n=len(y),positive=int(y.sum()),split_sizes=[len(tr),len(va),len(te)],
                holdout_seed=C['holdout_seed'],holdout_indices_sha256=hashlib.sha256(te.tobytes()).hexdigest(),
                proportions=proportions,profile_group_split=C['profile_group_split'],splitter=C['splitter'],
                split_sha256=file_hash(folder/'split_indices.npz'),
                training_sha256=file_hash(folder/'training_validation.npz'),
                test_sha256=file_hash(folder/'heldout_test.npz'))
    result['bundle_hash']=digest(result);write_json(folder/'bundle.json',result)
    return result


def load_training(root,job):
    folder=root/'bundles'/job['block_id'];meta=json.loads((folder/'bundle.json').read_text())
    if file_hash(folder/'training_validation.npz')!=meta['training_sha256']: raise RuntimeError('Training data hash mismatch')
    with np.load(folder/'training_validation.npz',allow_pickle=False) as z:
        return TrainingData(z['X'],z['y'],z['V'],z['v'],[z[f'train_{i}'] for i in range(K)],
                            [z[f'valid_{i}'] for i in range(K)],meta['bundle_hash'])


def method_config(method):
    return dict(contextual=method not in ('non_private','fixed_dp','adaptive_clip'),
                learn_action=method not in ('non_private','fixed_dp','adaptive_clip','rule','random','frozen'),
                gated=method.startswith('gate_'),learn_gate=method in ('gate_learned','gate_no_recycle','gate_constant','gate_noise_only'),
                recycle=method!='gate_no_recycle',private=method!='non_private')


def configurations(development=False):
    out=[]
    def add(d,s,a,e,m,cf=None,reward=None,suite='main',rounds=None):
        job=dict(dataset=d,seed=s,alpha=float(a),epsilon=float(e),method=m,
                 context_fraction=float(C['context_fraction'] if cf is None else cf),
                 feedback=C['feedback'] if reward is None else reward,
                 rounds=int(rounds or C['rounds']),suite=suite)
        job['block_id']=block_id(d,s,a);job['job_id']=digest(job)[:20];out.append(job)
    if development:
        for dataset,method in itertools.product(C['datasets'],C['main_methods']+C['acquisition_ablations']):
            add(dataset,C['development_seed'],C['ablation_alpha'],C['ablation_epsilon'],method,rounds=C['development_rounds'])
        return out
    for d,s,a,e,m in itertools.product(C['datasets'],C['seeds'],C['alphas'],C['epsilons'],C['main_methods']):
        reference_epsilon=C['ablation_epsilon'] if C['ablation_epsilon'] in C['epsilons'] else C['epsilons'][0]
        if m=='non_private' and e!=reference_epsilon:continue # no duplicate epsilon-independent runs
        add(d,s,a,e,m)
    if C['focused_ablations']:
        for d,s in itertools.product(C['datasets'],C['seeds']):
            a,e=C['ablation_alpha'],C['ablation_epsilon']
            for m in C['acquisition_ablations']:
                add(d,s,a,e,m,suite='ablation')
    return out


def lock_study(root,development=False):
    validate_config(); root.mkdir(parents=True,exist_ok=True)
    if (root/'protocol_lock.json').exists(): return verify_lock(root,development)
    inv=record_invocation(root,'development_lock' if development else 'lock')
    preflight=dataset_preflight(root/'dataset_checks')
    jobs=configurations(development)
    if set(j['dataset'] for j in jobs)!=set(C['datasets']):raise AssertionError('Dataset missing from experiment plan')
    blocks={j['block_id']:(j['dataset'],j['seed'],j['alpha']) for j in jobs}
    bundles={}
    for index,(bid,args) in enumerate(blocks.items()):
        print(f'Prepare data {index+1}/{len(blocks)}: {args}',flush=True)
        bundles[bid]=make_bundle(root,*args)
    for dataset in C['datasets']:
        hashes={b['holdout_indices_sha256'] for b in bundles.values() if b['dataset']==dataset}
        if len(hashes)!=1:raise AssertionError('Final test membership differs across training seeds')
    (root/'public_sources').mkdir(exist_ok=True)
    for name,data in _SOURCE_BYTES.items():(root/'public_sources'/f'{name}.csv').write_bytes(data)
    body=dict(version=VERSION,development=development,configuration=C,implementation_sha256=inv['implementation_sha256'],
              environment=environment(),jobs=jobs,bundles=bundles,dataset_preflight=preflight,
              primary_contrast=['gate_learned','gate_frozen'],
              primary_estimand='For each dataset: mean paired AP difference across seeds; first average main alpha/epsilon conditions within each seed.',
              inference_scope='Monte Carlo variation conditional on these fixed public datasets; not external-patient population inference.',
              previous_test_exposure=C['previous_test_exposure'],local_lock_not_external_preregistration=True)
    body['protocol_sha256']=digest(body);write_json(root/'protocol_lock.json',body)
    write_json(root/'study_status.json',dict(status='locked',planned_runs=len(jobs),test_opened=False))
    pd.DataFrame(jobs).to_csv(root/'planned_runs.csv',index=False)
    print('LOCKED',body['protocol_sha256'],'planned runs',len(jobs),flush=True)
    return jsonable(body)


def verify_lock(root,development=False):
    lock=json.loads((root/'protocol_lock.json').read_text());copy=dict(lock);expected=copy.pop('protocol_sha256')
    if digest(copy)!=expected: raise RuntimeError('Protocol lock was modified')
    if lock['configuration']!=jsonable(C): raise RuntimeError('Configuration changed. Restore it, or create a new study directory and disclose a new protocol.')
    if lock['implementation_sha256']!=source_capture()[1]: raise RuntimeError('Algorithm changed since locking. Do not mix implementations.')
    if lock['development']!=development: raise RuntimeError('Development and final study directories must remain separate')
    if C['strict_environment'] and lock['environment']!=environment(): raise RuntimeError('Package/Python environment differs from locked environment')
    return lock

# ----------------------------- Q controllers -----------------------------
class QNetwork:
    def __init__(self,seed,actions):
        self.layers=init_layers([9,64,32,actions],np.random.default_rng(seed))
        self.m=[np.zeros_like(a) for layer in self.layers for a in layer]
        self.v=[a.copy() for a in self.m];self.steps=0
    def values(self,x,cache=False):
        h=np.atleast_2d(x);history=[]
        for j,(w,b) in enumerate(self.layers):
            z=h@w+b;history.append((h,z));h=np.maximum(z,0) if j<2 else z
        return (h,history) if cache else h
    def train(self,states,actions,targets):
        q,cache=self.values(states,True);err=q[np.arange(len(q)),actions]-targets
        loss=np.mean(np.where(abs(err)<1,.5*err**2,abs(err)-.5))
        d=np.zeros_like(q);d[np.arange(len(q)),actions]=np.clip(err,-1,1)/len(q)
        grads=[None]*3
        for j in range(2,-1,-1):
            grads[j]=[cache[j][0].T@d,d.sum(0)]
            if j:d=(d@self.layers[j][0].T)*(cache[j-1][1]>0)
        flat=[a for layer in grads for a in layer]
        norm=math.sqrt(sum(float(np.sum(g*g)) for g in flat));scale=min(1.,5/max(norm,1e-12))
        self.steps+=1
        for i,(param,g) in enumerate(zip([a for layer in self.layers for a in layer],flat)):
            g=g*scale;self.m[i]=.9*self.m[i]+.1*g;self.v[i]=.999*self.v[i]+.001*g*g
            param-=C['q_lr']*(self.m[i]/(1-.9**self.steps))/(np.sqrt(self.v[i]/(1-.999**self.steps))+1e-8)
        if not np.isfinite(flatten_layers(self.layers)).all():raise FloatingPointError('Non-finite Q parameters')
        return float(loss)

class Controller:
    def __init__(self,seed,actions=15):
        self.actions=actions;self.online=QNetwork(seed,actions);self.target=QNetwork(seed,actions)
        self.initial=QNetwork(seed,actions);self.rng=np.random.default_rng(stable_seed(seed,'replay'))
        self.action_rng=np.random.default_rng(stable_seed(seed,'actions'));self.losses=[]
        self.replay=deque(maxlen=C['replay_capacity'])
    def act(self,state,progress,rule=None):
        probability=C['exploration_start']+(C['exploration_end']-C['exploration_start'])*progress
        u=self.action_rng.random();random_action=int(self.action_rng.integers(self.actions))
        explored=bool(u<probability)
        greedy=int(np.argmax(self.online.values(state)[0]));frozen=int(np.argmax(self.initial.values(state)[0]))
        if rule=='random':action=random_action;explored=True
        elif explored:action=random_action
        elif rule=='rule':action=int(np.clip(np.floor(state[0]*3),0,2))*5+int(np.clip(np.floor(state[1]*5),0,4))
        else:action=greedy
        return action,explored,greedy,frozen
    def observe(self,state,action,reward,next_state,done,learn):
        self.replay.append((np.asarray(state).copy(),int(action),float(reward),np.asarray(next_state).copy(),bool(done)))
        batch_size=C['learning_batch']
        if not learn or len(self.replay)<batch_size:return None
        indices=self.rng.choice(len(self.replay),batch_size,replace=False);batch=[self.replay[j] for j in indices]
        ss=np.stack([x[0] for x in batch]);aa=np.array([x[1] for x in batch]);rr=np.array([x[2] for x in batch])
        nxt=np.stack([x[3] for x in batch]);terminal=np.array([x[4] for x in batch])
        greedy=np.argmax(self.online.values(nxt),axis=1)
        target=rr+C['discount']*(1-terminal)*self.target.values(nxt)[np.arange(batch_size),greedy]
        loss=self.online.train(ss,aa,target);self.losses.append(loss)
        if len(self.losses)%C['target_every']==0:self.target.layers=copy_layers(self.online.layers)
        return loss
    def state_dict(self):
        return dict(online=self.online.layers,target=self.target.layers,initial=self.initial.layers,
                    m=self.online.m,v=self.online.v,steps=self.online.steps,replay=list(self.replay),losses=self.losses,
                    replay_rng=self.rng.bit_generator.state,action_rng=self.action_rng.bit_generator.state)
    def restore(self,d):
        for attr in ('online','target','initial'):getattr(self,attr).layers=[[np.asarray(a) for a in l] for l in d[attr]]
        self.online.m=[np.asarray(a) for a in d['m']];self.online.v=[np.asarray(a) for a in d['v']];self.online.steps=d['steps']
        self.replay=deque([(np.asarray(s),a,r,np.asarray(ns),done) for s,a,r,ns,done in d['replay']],maxlen=C['replay_capacity'])
        self.losses=d['losses'];self.rng.bit_generator.state=d['replay_rng'];self.action_rng.bit_generator.state=d['action_rng']

# ------------------------- selective-context training -------------------------
def clipping_fraction(X,y,layers):
    count=0
    for start in range(0,len(y),BATCH_CHUNK):
        sl=slice(start,start+BATCH_CHUNK)
        norms=per_example_backprop(X[sl],y[sl],layers)[3]
        count+=int(np.sum(norms<=BASE_CLIP))
    return count/len(y)


def slot_costs(slot,context_fraction,allocation,contextual,adaptive,query):
    if not contextual:
        clip=slot*C['clip_fraction'] if adaptive else 0.
        return dict(context=0.,clipping=clip,gradient=slot-clip,feedback=0.)
    # Budget saved on context goes entirely to the gradient; feedback cost is unchanged.
    available=slot*(1-context_fraction-C['clip_fraction'])
    context=slot*context_fraction if query else 0.
    feedback=available*(1-allocation)
    clipping=slot*C['clip_fraction']
    gradient=available*allocation+(slot*context_fraction-context)
    out=dict(context=context,clipping=clipping,gradient=gradient,feedback=feedback)
    if abs(sum(out.values())-slot)>1e-10:raise AssertionError('Slot does not balance')
    return out


def protect_context(raw,method,rho,n,noise,mask_rng):
    protected=np.clip(release(raw,math.sqrt(5)/n,rho,noise),0,1)
    observed=protected.copy()
    if method in ('zero_context','gate_constant'):observed[:]=.5
    elif method in ('noise_only','gate_noise_only'):
        # Independent synthetic draw: never subtract this from the data release.
        observed=np.clip(.5+noise.normal(math.sqrt(5)/n/math.sqrt(2*rho),(5,)),0,1)
    elif method=='permuted_context':observed=observed[mask_rng.permutation(5)]
    elif method.startswith('drop_'):observed[int(method[-1])]=.5
    return observed,protected


def bounded_feedback(y,p,kind,rho,noise):
    if kind=='hist_ap':
        bins=C['feedback_bins'];hist=np.zeros((2,bins))
        np.add.at(hist,(y,np.minimum((p*bins).astype(int),bins-1)),1)
        protected=release(hist/len(y),math.sqrt(2)/len(y),rho,noise)
        metric=histogram_metrics(protected)['hist_ap']
        return (.5 if metric is None else metric),math.sqrt(2)/len(y)
    values=1-(p-y)**2 if kind=='brier' else 1-np.abs(p-y)
    score=float(np.clip(release(float(values.mean()),1/len(y),rho,noise),0,1))
    return score,1/len(y)


def checkpoint_write(path,state):
    raw=canonical(state).encode();temp=path.with_suffix('.tmp')
    temp.write_bytes(gzip.compress(raw));temp.replace(path)

def checkpoint_read(path):return json.loads(gzip.decompress(path.read_bytes()))

def train_job(data,job,folder,protocol_sha256,stop_after_round=None):
    folder.mkdir(parents=True,exist_ok=True); flags=method_config(job['method']);R=job['rounds'];seed=job['seed']
    started=time.perf_counter();cap=eps_to_rho(job['epsilon']);training_cap=cap*(1-C['evaluation_fraction'])
    schedule=np.random.default_rng(stable_seed(seed,'participation',R)).random((R,K))<C['participation']
    slots=schedule.sum(0)
    if np.any(slots==0):raise RuntimeError('Public schedule has a client with no slots; lock a revised protocol')
    rng=np.random.default_rng(stable_seed(seed,job['dataset'],'model'))
    shared=init_layers([data.X.shape[1],*C['encoder']],rng)
    base_head=init_layers([C['encoder'][-1],C['head'],1],rng)
    initialisation_hash=digest([shared,base_head])
    heads=[copy_layers(base_head) for _ in range(K)];local=[copy_layers(shared) for _ in range(K)]
    previous=[copy_layers(shared+base_head) for _ in range(K)]
    actor=Controller(stable_seed(seed,'allocation'));gate=Controller(stable_seed(seed,'gate'),2)
    noise=BenchmarkNoise(stable_seed(job['job_id'],'mechanism')) if C['noise_mode']=='benchmark' else Noise()
    drop_rng=np.random.default_rng(stable_seed(seed,'dropout'));mask_rng=np.random.default_rng(stable_seed(seed,'mask'))
    gate_random=np.random.default_rng(stable_seed(seed,'query_schedule'))
    ledgers=[Ledger(cap) for _ in range(K)];feedback=np.full(K,.5);cached=np.full((K,5),.5)
    ages=np.zeros(K,int);visits=np.zeros(K,int);pending=[None]*K;gate_pending=[None]*K
    decisions=[];events=[];traces=[];start_round=0;terminal_done=False;training_updates=0;gate_training_updates=0
    elapsed_previous=0.;checkpoint=folder/'training_checkpoint.json.gz'
    identity=dict(job=job,protocol_sha256=protocol_sha256,bundle_hash=data.bundle_hash)
    if checkpoint.exists():
        state=checkpoint_read(checkpoint)
        if state['identity']!=identity:raise RuntimeError('Checkpoint identity mismatch')
        shared=[[np.asarray(a) for a in l] for l in state['shared']]
        def restore_models(key):return [[[np.asarray(a) for a in l] for l in model] for model in state[key]]
        heads=restore_models('heads');local=restore_models('local');previous=restore_models('previous')
        actor.restore(state['actor']);gate.restore(state['gate'])
        if C['noise_mode']=='benchmark':noise.rng.bit_generator.state=state['noise_rng']
        drop_rng.bit_generator.state=state['drop_rng'];mask_rng.bit_generator.state=state['mask_rng']
        gate_random.bit_generator.state=state['gate_rng'];ledgers=[Ledger(**x) for x in state['ledgers']]
        feedback=np.asarray(state['feedback']);cached=np.asarray(state['cached']);ages=np.asarray(state['ages']);visits=np.asarray(state['visits'])
        pending=state['pending'];gate_pending=state['gate_pending'];decisions=state['decisions'];events=state['events'];traces=state['traces']
        start_round=state['next_round'];terminal_done=state['terminal_done'];training_updates=state['training_updates']
        gate_training_updates=state['gate_training_updates'];elapsed_previous=state['elapsed_seconds']
    def save(next_round):
        checkpoint_write(checkpoint,dict(identity=identity,shared=shared,heads=heads,local=local,previous=previous,
          actor=actor.state_dict(),gate=gate.state_dict(),noise_rng=noise.rng.bit_generator.state if C['noise_mode']=='benchmark' else None,
          drop_rng=drop_rng.bit_generator.state,mask_rng=mask_rng.bit_generator.state,gate_rng=gate_random.bit_generator.state,
          ledgers=[dict(cap=l.cap,rho=l.rho,events=l.events) for l in ledgers],feedback=feedback,cached=cached,ages=ages,
          visits=visits,pending=pending,gate_pending=gate_pending,decisions=decisions,events=events,traces=traces,
          next_round=next_round,terminal_done=terminal_done,training_updates=training_updates,gate_training_updates=gate_training_updates,
          elapsed_seconds=elapsed_previous+time.perf_counter()-started))
    def update(controller,old,next_state,learn,kind,round_number,client,decision,terminal=False):
        if old is None:return
        loss=controller.observe(*old,next_state,terminal,learn)
        if loss is not None:events.append(dict(network=kind,round=round_number,client=client,decision=decision,
                    updates=len(controller.losses),loss=loss,phase='terminal' if terminal else 'before_decision'))
    for t in range(start_round,R):
        proposals=[];round_start=len(decisions)
        for i0 in np.flatnonzero(schedule[t]):
            i=int(i0);ledger=ledgers[i];slot=training_cap/slots[i];decision=len(decisions)+1
            if flags['private'] and (ledger.rho+slot>training_cap+1e-10 or not ledger.can([slot,cap*C['evaluation_fraction']])):
                raise RuntimeError('Prospective budget reservation failed BEFORE any query')
            progress=t/max(R-1,1)
            history_state=np.r_[cached[i],progress,ledger.rho/cap,feedback[i],min(ages[i]/10,1.)]
            update(gate,gate_pending[i],history_state,flags['learn_gate'],'gate',t+1,i,decision)
            gate_pending[i]=None
            request=1;gate_explored=False;gate_greedy=None;gate_initial=None;forced=False
            if flags['gated']:
                request,gate_explored,gate_greedy,gate_initial=gate.act(history_state,progress)
                if job['method']=='gate_periodic':request=int(visits[i]%C['periodic_every']==0);gate_explored=False
                if job['method']=='gate_random':request=int(gate_random.random()<C['random_query_probability']);gate_explored=True
                if visits[i]==0:request=1;forced=True
            actual_query=bool(flags['contextual'] and (request or not flags['recycle']))
            enc=[[(1-C['blend'])*a+C['blend']*b for a,b in zip(s,l)] for s,l in zip(shared,local[i])]
            layers=copy_layers(enc+heads[i]);idx=data.clients[i];vidx=data.validation_clients[i]
            raw=None;released=None;mae=None;saturation=None
            # The request decision above cannot inspect fresh raw context or validation labels.
            if actual_query:
                raw,flag=context_values(data.X[idx],data.y[idx],layers,previous[i])
                observed,released=protect_context(raw,job['method'],slot*job['context_fraction'],len(idx),noise,mask_rng)
                ledger.spend('context' if request else 'discarded_context',slot*job['context_fraction'],round=t+1,
                             sensitivity=math.sqrt(5)/len(idx))
                if request:cached[i]=observed;ages[i]=0
                mae=float(np.mean(abs(released-raw)));saturation=float(np.mean((released==0)|(released==1)))
            elif flags['private'] and job['method']!='fixed_dp':
                flag=clipping_fraction(data.X[idx],data.y[idx],layers)
            if not flags['contextual']:cached[i]=.5
            state=np.r_[cached[i],progress,ledger.rho/cap,feedback[i],min(ages[i]/10,1.)]
            update(actor,pending[i],state,flags['learn_action'],'allocation',t+1,i,decision)
            pending[i]=None
            if flags['contextual']:
                action,explored,greedy,initial=actor.act(state,progress,job['method'] if job['method'] in ('rule','random') else None)
            else:action,explored,greedy,initial=FIXED_ACTION,False,None,None
            multiplier,allocation=ACTIONS[action];clip=BASE_CLIP*(multiplier if flags['contextual'] else 1.)
            costs=slot_costs(slot,job['context_fraction'],allocation,flags['contextual'],job['method']!='fixed_dp',actual_query)
            if flags['private'] and costs['clipping']:
                protected_flag=float(np.clip(release(flag,1/len(idx),costs['clipping'],noise),0,1))
                ledger.spend('clipping',costs['clipping'],round=t+1,sensitivity=1/len(idx))
                clip*=math.exp(.2*(.8-protected_flag))
            for step in range(C['local_steps']):
                gradient=clipped_mean_gradient(data.X[idx],data.y[idx],layers,clip if flags['private'] else 1e100,drop_rng)
                if flags['private']:
                    cost=costs['gradient']/C['local_steps'];gradient=release(gradient,2*clip/len(idx),cost,noise)
                    ledger.spend('gradient',cost,round=t+1,step=step,sensitivity=2*clip/len(idx),clip=clip)
                params=flatten_layers(layers);nenc=len(flatten_layers(layers[:2]))
                rate=np.r_[np.full(nenc,C['lr']),np.full(len(params)-nenc,C['head_lr'])]
                layers=assign_vector(params-rate*gradient,layers)
                if not np.isfinite(flatten_layers(layers)).all():raise FloatingPointError('Non-finite model')
            local[i]=copy_layers(layers[:2]);heads[i]=copy_layers(layers[2:]);previous[i]=copy_layers(enc+heads[i])
            proposals.append(flatten_layers(layers[:2])-flatten_layers(enc))
            reward=None
            if flags['contextual']:
                p=predict(data.V[vidx],layers)
                new_feedback,sensitivity=bounded_feedback(data.v[vidx],p,job['feedback'],costs['feedback'],noise)
                ledger.spend('feedback_'+job['feedback'],costs['feedback'],round=t+1,sensitivity=sensitivity)
                reward=float(np.clip(new_feedback-feedback[i],-1,1));feedback[i]=new_feedback
                pending[i]=(state.copy(),action,reward)
                if flags['gated']:gate_pending[i]=(history_state.copy(),request,reward)
            visits[i]+=1;ages[i]+=1
            decisions.append(dict(round=t+1,client=i,decision=decision,action=int(action),exploratory=explored,
              allocation_updates_before_action=len(actor.losses),allocation_greedy=greedy,allocation_initial_greedy=initial,
              allocation_greedy_changed=bool(greedy!=initial) if flags['contextual'] else False,
              allocation_parameter_shift=float(np.linalg.norm(flatten_layers(actor.online.layers)-flatten_layers(actor.initial.layers))),
              gate_updates_before_query=len(gate.losses),gate_request=int(request) if flags['gated'] else None,
              gate_parameter_shift=float(np.linalg.norm(flatten_layers(gate.online.layers)-flatten_layers(gate.initial.layers))),
              gate_greedy=gate_greedy,gate_initial_greedy=gate_initial,gate_exploratory=gate_explored,gate_forced=forced,
              gate_greedy_changed=bool(gate_greedy!=gate_initial) if flags['gated'] else False,
              queried_fresh_context=actual_query,context_used_fresh=bool(actual_query and request),
              state=state,gate_state=history_state if flags['gated'] else None,released_context=released,
              context_mae_PUBLIC_ONLY=mae,context_saturation=saturation,
              context_age=int(ages[i]-1),reward=reward,protected_feedback=float(feedback[i]),
              q_loss=actor.losses[-1] if actor.losses else None,gate_loss=gate.losses[-1] if gate.losses else None,
              clipping_norm=clip,gradient_rho=costs['gradient'] if flags['private'] else 0.,
              feedback_rho=costs['feedback'] if flags['private'] else 0.,
              context_rho=costs['context'] if flags['private'] else 0.,
              configured_slot_rho=slot if flags['private'] else 0.,epsilon=rho_to_eps(ledger.rho) if flags['private'] else None))
            if flags['private'] and abs(ledger.rho-slot*visits[i])>1e-8:raise AssertionError('Incomplete or excess slot accounting')
        if proposals:shared=assign_vector(flatten_layers(shared)+np.mean(proposals,axis=0),shared)
        traces.append(dict(round=t+1,decisions=len(decisions)-round_start,allocation_updates=len(actor.losses),
                           gate_updates=len(gate.losses),mean_protected_feedback=float(feedback.mean()),
                           max_configured_epsilon=max(rho_to_eps(l.rho) for l in ledgers) if flags['private'] else None))
        if callable(globals().get('APP_PROGRESS')): APP_PROGRESS(t+1, R, traces[-1])
        if (t+1)%C['checkpoint_every']==0 or t+1==R:save(t+1)
        if stop_after_round is not None and t+1>=stop_after_round:
            save(t+1);return {'status':'interrupted_for_resume_test'}
    if not terminal_done:
        training_updates=len(actor.losses);gate_training_updates=len(gate.losses)
        for i in range(K):
            terminal_state=np.r_[cached[i],1.,ledgers[i].rho/cap,feedback[i],min(ages[i]/10,1.)]
            update(actor,pending[i],terminal_state,flags['learn_action'],'allocation',R,i,None,True)
            update(gate,gate_pending[i],terminal_state,flags['learn_gate'],'gate',R,i,None,True)
        terminal_done=True;save(R)
    # Learning failures are recorded, never censored based on utility or action changes.
    learning_ok=(not flags['learn_action'] or training_updates>0) and (not flags['learn_gate'] or gate_training_updates>0)
    summary=dict(**job,status='trained',learning_timing_pass=learning_ok,allocation_training_updates=training_updates,
       allocation_terminal_updates=len(actor.losses)-training_updates,gate_training_updates=gate_training_updates,
       gate_terminal_updates=len(gate.losses)-gate_training_updates,decisions=len(decisions),
       actions_after_update=sum(d['allocation_updates_before_action']>0 for d in decisions),
       changed_greedy_after_update=sum(d['allocation_updates_before_action']>0 and d['allocation_greedy_changed'] for d in decisions),
       changed_executed_nonexploratory=sum(d['allocation_updates_before_action']>0 and d['allocation_greedy_changed'] and not d['exploratory'] for d in decisions),
       gate_decisions_after_update=sum(d['gate_updates_before_query']>0 for d in decisions),
       gate_changed_nonexploratory=sum(d['gate_updates_before_query']>0 and d['gate_greedy_changed'] and not d['gate_exploratory'] and not d['gate_forced'] for d in decisions),
       context_query_rate=float(np.mean([d['queried_fresh_context'] for d in decisions])),
       training_rho_max=max(l.rho for l in ledgers) if flags['private'] else None,
       configured_epsilon=job['epsilon'] if flags['private'] else None,noise_mode=C['noise_mode'],release_dp_claim=False,
       elapsed_seconds=elapsed_previous+time.perf_counter()-started,initialisation_hash=initialisation_hash,
       schedule_hash=hashlib.sha256(schedule.tobytes()).hexdigest(),bundle_hash=data.bundle_hash,
       first_allocation_update=next((e for e in events if e['network']=='allocation' and e['phase']=='before_decision'),None),
       first_gate_update=next((e for e in events if e['network']=='gate' and e['phase']=='before_decision'),None))
    write_json(folder/'training_summary.json',summary);write_json(folder/'decision_log_PUBLIC_ONLY.json',decisions)
    pd.DataFrame(events).to_csv(folder/'q_updates.csv',index=False);pd.DataFrame(traces).to_csv(folder/'rounds.csv',index=False)
    write_json(folder/'training_ledger.json',[l.events for l in ledgers])
    arrays={'shared':flatten_layers(shared),'input_dim':np.array(data.X.shape[1]),'training_prevalence_PUBLIC_ONLY':np.array(data.y.mean())}
    arrays.update({f'head_{i}':flatten_layers(h) for i,h in enumerate(heads)})
    np.savez_compressed(folder/'final_model.npz',**arrays)
    write_json(folder/'TRAIN_COMPLETE.json',dict(protocol_sha256=protocol_sha256,job_id=job['job_id'],
        files={name:file_hash(folder/name) for name in ['final_model.npz','training_summary.json','decision_log_PUBLIC_ONLY.json','training_ledger.json','q_updates.csv','rounds.csv']}))
    return summary

# -------------------- held-out evaluation and metric audit --------------------
def exact_metrics(y,p):
    y=np.asarray(y);p=np.asarray(p)
    if len(y)==0:return dict(n=0,positives=0,ap=None,auroc=None,brier=None,ece=None,recall=None,specificity=None,f1=None)
    both=len(np.unique(y))==2;positive=int(y.sum());negative=len(y)-positive
    if not np.isfinite(p).all():raise FloatingPointError('Non-finite predictions')
    bins=np.minimum((p*10).astype(int),9);ece=0.
    for b in range(10):
        take=bins==b
        if take.any():ece+=take.mean()*abs(p[take].mean()-y[take].mean())
    return dict(n=len(y),positives=positive,negative=negative,ap=float(average_precision_score(y,p)) if positive else None,
                auroc=float(roc_auc_score(y,p)) if both else None,brier=float(brier_score_loss(y,p)),ece=float(ece),
                recall=float(np.mean(p[y==1]>=.5)) if positive else None,
                specificity=float(np.mean(p[y==0]<.5)) if negative else None,
                f1=float(f1_score(y,p>=.5,zero_division=0)))

def noise_for(job,purpose):
    return BenchmarkNoise(stable_seed(job['job_id'],purpose)) if C['noise_mode']=='benchmark' else Noise()

def model_from_archive(path):
    with np.load(path,allow_pickle=False) as z:
        d=int(z['input_dim']);rng=np.random.default_rng(0)
        enc=init_layers([d,*C['encoder']],rng);head=init_layers([C['encoder'][-1],C['head'],1],rng)
        return assign_vector(z['shared'],enc),[assign_vector(z[f'head_{i}'],head) for i in range(K)],float(z['training_prevalence_PUBLIC_ONLY'])

def audit_histogram(y,p,job,client):
    exact=exact_metrics(y,p)['ap'];rows=[];base=eps_to_rho(job['epsilon'])*C['evaluation_fraction']
    for bins,multiplier in itertools.product(C['audit_bins'],C['audit_multipliers']):
        hist=np.zeros((2,bins));np.add.at(hist,(y,np.minimum((p*bins).astype(int),bins-1)),1);hist/=len(y)
        binned=histogram_metrics(hist)['hist_ap'];rho=base*multiplier
        for repeat in range(C['audit_repeats']):
            rng=BenchmarkNoise(stable_seed(job['job_id'],'audit',client,bins,multiplier,repeat))
            noisy=histogram_metrics(release(hist,math.sqrt(2)/len(y),rho,rng))['hist_ap']
            error=noisy-exact if noisy is not None and exact is not None else None
            rows.append(dict(client=client,n=len(y),positives=int(y.sum()),bins=bins,multiplier=multiplier,rho_per_draw=rho,
                        repeat=repeat,exact_ap=exact,binned_ap=binned,noisy_ap=noisy,error=error,
                        absolute_error=abs(error) if error is not None else None,
                        squared_error=error**2 if error is not None else None,public_simulation_only=True))
    return rows


def verify_complete(folder,marker,protocol):
    path=folder/marker
    if not path.exists():return False
    record=json.loads(path.read_text())
    if record['protocol_sha256']!=protocol:raise RuntimeError('Completion record belongs to another protocol')
    for name,expected in record['files'].items():
        if not (folder/name).is_file() or file_hash(folder/name)!=expected:raise RuntimeError('Completed artifact changed: '+str(folder/name))
    return True


def evaluate_job(root,job,lock,development=False):
    folder=root/'runs'/job['job_id'];protocol=lock['protocol_sha256'];mode='validation' if development else 'test'
    if not development:
        gate_path=root/'EVALUATION_OPENED.json'
        if not gate_path.exists():raise RuntimeError('Call evaluate_study: global model commitment is required first')
        committed=json.loads(gate_path.read_text())
        if committed['protocol_sha256']!=protocol or committed['models'].get(job['job_id'])!=file_hash(folder/'final_model.npz'):
            raise RuntimeError('Model differs from the globally committed final model')
    if not verify_complete(folder,'TRAIN_COMPLETE.json',protocol):raise RuntimeError('Model not committed before evaluation')
    if verify_complete(folder,'EVAL_COMPLETE.json',protocol):return json.loads((folder/'evaluation.json').read_text())
    bundle=root/'bundles'/job['block_id'];meta=lock['bundles'][job['block_id']]
    if development:
        with np.load(bundle/'training_validation.npz',allow_pickle=False) as z:
            X,y=z['V'],z['v'];groups=[z[f'valid_{i}'] for i in range(K)]
    else:
        if file_hash(bundle/'heldout_test.npz')!=meta['test_sha256']:raise RuntimeError('Held-out data changed after lock')
        with np.load(bundle/'heldout_test.npz',allow_pickle=False) as z:
            X,y=z['X'],z['y'];groups=[z[f'client_{i}'] for i in range(K)]
    shared,heads,train_prevalence=model_from_archive(folder/'final_model.npz')
    local=[];common=[];predictions={};histograms=[];audit=[];noise=noise_for(job,'final_evaluation')
    flags=method_config(job['method']);eval_cost=eps_to_rho(job['epsilon'])*C['evaluation_fraction']
    train_ledgers=json.loads((folder/'training_ledger.json').read_text());ledger_rows=[]
    # Costly Monte Carlo measurement audit is focused, prospectively, on the anchor setting.
    do_audit=(job['suite']=='main' and job['method']!='non_private' and job['alpha']==C['ablation_alpha'] and job['epsilon']==C['ablation_epsilon'])
    for i,head in enumerate(heads):
        p=predict(X,shared+head);ix=groups[i]
        common.append(dict(client=i,**exact_metrics(y,p)));local.append(dict(client=i,**exact_metrics(y[ix],p[ix])))
        if C['save_common_predictions']:predictions[f'head_{i}']=p
        hist=np.zeros((2,C['evaluation_bins']));np.add.at(hist,(y[ix],np.minimum((p[ix]*C['evaluation_bins']).astype(int),C['evaluation_bins']-1)),1)
        if flags['private']:
            prior=sum(x['rho'] for x in train_ledgers[i]);ledger=Ledger(eps_to_rho(job['epsilon']),prior)
            if not ledger.can([eval_cost]):raise RuntimeError('Evaluation reserve exhausted')
            noisy=release(hist/len(ix),math.sqrt(2)/len(ix),eval_cost,noise)
            ledger.spend('evaluation_histogram',eval_cost,sensitivity=math.sqrt(2)/len(ix))
            if abs(ledger.rho-eps_to_rho(job['epsilon']))>1e-8:raise AssertionError('Final cost mismatch')
            histograms.append(dict(client=i,histogram=noisy,**histogram_metrics(noisy)))
            ledger_rows.append(dict(client=i,training_rho=prior,evaluation_rho=eval_cost,total_rho=ledger.rho,
                                    epsilon=rho_to_eps(ledger.rho)))
        if do_audit:audit.extend(audit_histogram(y[ix],p[ix],job,i))
    common_frame=pd.DataFrame(common);local_frame=pd.DataFrame(local)
    result=dict(**job,evaluation_split=mode,development=development,n=len(y),positives=int(y.sum()),
      common_mean_head_ap=float(common_frame.ap.mean()),common_mean_head_auroc=float(common_frame.auroc.mean()),
      common_mean_head_brier=float(common_frame.brier.mean()),common_mean_head_ece=float(common_frame.ece.mean()),
      common_worst_head_ap=float(common_frame.ap.min()),common_head_ap_sd=float(common_frame.ap.std(ddof=0)),
      local_mean_ap=float(local_frame.ap.mean()),local_worst_ap=float(local_frame.ap.min()),
      valid_local_ap_clients=int(local_frame.ap.notna().sum()),valid_local_auroc_clients=int(local_frame.auroc.notna().sum()),
      test_prevalence_REFERENCE_ONLY=float(y.mean()),training_prevalence_baseline_brier=float(np.mean((y-train_prevalence)**2)),
      noise_mode=C['noise_mode'],release_dp_claim=False,model_sha256=file_hash(folder/'final_model.npz'),
      protocol_sha256=protocol,partition_hash=meta['split_sha256'],evaluation_source_sha256=meta['test_sha256'] if not development else meta['training_sha256'])
    common_frame.to_csv(folder/'common_head_metrics_PUBLIC_ONLY.csv',index=False)
    local_frame.to_csv(folder/'local_metrics_PUBLIC_ONLY.csv',index=False)
    if C['save_common_predictions']:
        predictions['labels']=y;predictions['client_assignment']=np.full(len(y),-1)
        for i,ix in enumerate(groups):predictions['client_assignment'][ix]=i
        np.savez_compressed(folder/'predictions_PUBLIC_ONLY.npz',**predictions)
    write_json(folder/'evaluation_histograms.json',histograms);pd.DataFrame(ledger_rows).to_csv(folder/'final_accounting.csv',index=False)
    if audit:pd.DataFrame(audit).to_csv(folder/'histogram_audit_PUBLIC_ONLY.csv',index=False)
    write_json(folder/'evaluation.json',result)
    names=['evaluation.json','common_head_metrics_PUBLIC_ONLY.csv','local_metrics_PUBLIC_ONLY.csv','evaluation_histograms.json','final_accounting.csv']
    if C['save_common_predictions']:names.append('predictions_PUBLIC_ONLY.npz')
    if audit:names.append('histogram_audit_PUBLIC_ONLY.csv')
    write_json(folder/'EVAL_COMPLETE.json',dict(protocol_sha256=protocol,job_id=job['job_id'],files={n:file_hash(folder/n) for n in names}))
    return result

# ------------------------------ statistical analysis ------------------------------
def paired_stats(differences,family_size=1):
    d=np.asarray(differences,dtype=float)
    if not np.isfinite(d).all():raise ValueError('Missing/non-finite differences must not be silently dropped')
    n=len(d);result=dict(n_seeds=n,mean_difference=float(d.mean()) if n else None,
                        sd_difference=float(d.std(ddof=1)) if n>1 else None,
                        wins=int((d>0).sum()),ties=int((d==0).sum()),losses=int((d<0).sum()))
    if n<2:return result
    mean=d.mean();se=d.std(ddof=1)/math.sqrt(n)
    tcrit=stats.t.ppf(.975,n-1);simcrit=stats.t.ppf(1-.05/(2*family_size),n-1)
    result.update(t_ci_low=float(mean-tcrit*se),t_ci_high=float(mean+tcrit*se),
                  simultaneous_t_low=float(mean-simcrit*se),simultaneous_t_high=float(mean+simcrit*se),
                  standard_error=float(se),zero_variance=bool(se==0))
    # Sign-flip randomisation assumes exchangeability of paired method labels / symmetric null differences.
    observed=abs(mean)
    if n<=18:
        bits=np.arange(2**n,dtype=np.uint32)[:,None]>>np.arange(n,dtype=np.uint32)
        null=((1-2*(bits&1).astype(float))*d).mean(1)
        p=float(np.mean(np.abs(null)>=observed-1e-14));exact=True
    else:
        rng=np.random.default_rng(721);null=(rng.choice([-1.,1.],(100000,n))*d).mean(1)
        p=float((1+(abs(null)>=observed-1e-14).sum())/(1+len(null)));exact=False
    rng=np.random.default_rng(9821);draws=rng.choice(d,(C['bootstrap_repeats'],n),replace=True).mean(1)
    lower,upper=np.quantile(draws,[.025,.975])
    result.update(sign_flip_p=p,exact_sign_flip=exact,bootstrap_low=float(lower),bootstrap_high=float(upper),
                  ci_excludes_zero=bool(result['t_ci_low']>0 or result['t_ci_high']<0),
                  practical_margin=C['practical_ap_margin'],
                  ci_inside_practical_band=bool(result['t_ci_low']>-C['practical_ap_margin'] and result['t_ci_high']<C['practical_ap_margin']))
    return result


def holm(pvalues):
    values=np.asarray(pvalues,float)
    if not np.isfinite(values).all():raise ValueError('Invalid p-value family')
    order=np.argsort(values);adjusted=np.empty(len(values));running=0.
    for j,k in enumerate(order):running=max(running,(len(values)-j)*values[k]);adjusted[k]=min(1.,running)
    return adjusted


def analyse(root,lock,development=False):
    out=root/'analysis_PUBLIC_ONLY';out.mkdir(exist_ok=True);rows=[];training=[];missing=[]
    for job in lock['jobs']:
        folder=root/'runs'/job['job_id']
        if not verify_complete(folder,'EVAL_COMPLETE.json',lock['protocol_sha256']):missing.append(job['job_id']);continue
        rows.append(json.loads((folder/'evaluation.json').read_text()))
        training.append(json.loads((folder/'training_summary.json').read_text()))
    coverage=[]
    for dataset in C['datasets']:
        planned=sum(j['dataset']==dataset for j in lock['jobs']);evaluated=sum(r['dataset']==dataset for r in rows)
        coverage.append(dict(dataset=dataset,planned_runs=planned,evaluated_runs=evaluated,complete=planned>0 and planned==evaluated))
    pd.DataFrame(coverage).to_csv(out/'dataset_coverage.csv',index=False)
    complete=not missing and all(r['complete'] for r in coverage)
    write_json(out/'completeness.json',dict(planned=len(lock['jobs']),evaluated=len(rows),missing_job_ids=missing,
               inferential_analysis_allowed=bool(complete and not development),development=development))
    if not rows:return
    frame=pd.DataFrame(rows);frame.to_csv(out/'individual_runs.csv',index=False)
    pd.DataFrame(training).to_csv(out/'controller_learning_evidence.csv',index=False)
    keys=['suite','dataset','alpha','epsilon','rounds','context_fraction','feedback','method']
    summary=frame.groupby(keys,dropna=False).agg(n_seeds=('seed','nunique'),AP_mean=('common_mean_head_ap','mean'),
      AP_SD=('common_mean_head_ap','std'),AUROC_mean=('common_mean_head_auroc','mean'),Brier_mean=('common_mean_head_brier','mean'),
      ECE_mean=('common_mean_head_ece','mean'),minimum_positive_labels=('positives','min')).reset_index()
    summary.to_csv(out/'main_comparison.csv',index=False)
    local_frames=[];audit_summaries=[];costs=[];action_frequencies=[]
    for job in lock['jobs']:
        folder=root/'runs'/job['job_id']
        if not (folder/'EVAL_COMPLETE.json').exists():continue
        local=pd.read_csv(folder/'local_metrics_PUBLIC_ONLY.csv')
        for key in ['job_id','dataset','seed','alpha','epsilon','method','suite']:local[key]=job[key]
        local_frames.append(local)
        decisions=pd.DataFrame(json.loads((folder/'decision_log_PUBLIC_ONLY.json').read_text()))
        for action,count in decisions.action.value_counts().items():
            action_frequencies.append(dict(**job,action=int(action),count=int(count),frequency=float(count/len(decisions)),
              clip_multiplier=ACTIONS[int(action)][0],gradient_allocation=ACTIONS[int(action)][1]))
        ledger=json.loads((folder/'training_ledger.json').read_text())
        for client,events in enumerate(ledger):
            totals=defaultdict(float)
            for event in events:totals[event['kind']]+=event['rho']
            for kind,total in totals.items():costs.append(dict(job_id=job['job_id'],dataset=job['dataset'],seed=job['seed'],method=job['method'],client=client,mechanism=kind,rho=total))
        if (folder/'histogram_audit_PUBLIC_ONLY.csv').exists():
            h=pd.read_csv(folder/'histogram_audit_PUBLIC_ONLY.csv')
            for (client,bins,mult),g in h.groupby(['client','bins','multiplier']):
                errors=g.error.dropna();mean_error=float(errors.mean()) if len(errors) else None
                audit_summaries.append(dict(**job,client=client,bins=bins,multiplier=mult,draws=len(g),defined_draws=len(errors),
                  local_n=int(g.n.iloc[0]),positives=int(g.positives.iloc[0]),exact_ap=g.exact_ap.iloc[0],
                  binned_error=float(g.binned_ap.iloc[0]-g.exact_ap.iloc[0]),bias=mean_error,
                  mae=float(errors.abs().mean()) if len(errors) else None,
                  rmse=float(np.sqrt(np.mean(errors**2))) if len(errors) else None,
                  mc_se_bias=float(errors.std(ddof=1)/math.sqrt(len(errors))) if len(errors)>1 else None))
    if local_frames:pd.concat(local_frames,ignore_index=True).to_csv(out/'local_support_and_metrics.csv',index=False)
    pd.DataFrame(costs).to_csv(out/'training_cost_components.csv',index=False)
    pd.DataFrame(action_frequencies).to_csv(out/'action_frequencies.csv',index=False)
    if audit_summaries:pd.DataFrame(audit_summaries).to_csv(out/'histogram_error_by_model_client.csv',index=False)
    if complete and not development:
        main=frame[frame.suite=='main'];primary=[];seed_rows=[];secondary=[]
        contrasts=[('gate_learned','gate_frozen'),('gate_learned','learned'),('learned','frozen'),
                   ('learned','fixed_dp'),('learned','adaptive_clip'),('learned','random'),('learned','rule')]
        for first,second in contrasts:
            pivot=main[main.method.isin([first,second])].pivot(index=['dataset','seed','alpha','epsilon'],columns='method',values='common_mean_head_ap')
            if first not in pivot or second not in pivot:raise RuntimeError('A planned contrast is unavailable')
            pivot['difference']=pivot[first]-pivot[second]
            if pivot.difference.isna().any():raise RuntimeError('Incomplete pairs; do not silently analyse complete cases')
            for dataset,group in pivot.groupby(level='dataset'):
                per_seed=group['difference'].groupby(level='seed').mean()
                if set(per_seed.index)!=set(C['seeds']):raise RuntimeError('Missing seed in primary family')
                expected=len(C['alphas'])*len(C['epsilons'])
                if not (group.groupby(level='seed').size()==expected).all():raise RuntimeError('Missing condition within seed')
                for seed,value in per_seed.items():seed_rows.append(dict(dataset=dataset,seed=seed,first=first,second=second,mean_condition_difference=value))
                if (first,second)==tuple(lock['primary_contrast']):
                    primary.append(dict(dataset=dataset,first=first,second=second,**paired_stats(per_seed.to_numpy(),len(C['datasets']))))
            for (dataset,alpha,epsilon),group in pivot.groupby(level=['dataset','alpha','epsilon']):
                secondary.append(dict(dataset=dataset,alpha=alpha,epsilon=epsilon,first=first,second=second,**paired_stats(group.difference.to_numpy())))
        primary=pd.DataFrame(primary);secondary=pd.DataFrame(secondary)
        primary['holm_p']=holm(primary.sign_flip_p);primary['reject_at_0_05']=primary.holm_p<=.05
        secondary['holm_p_entire_secondary_family']=holm(secondary.sign_flip_p)
        primary.to_csv(out/'PRIMARY_paired_dataset_comparisons.csv',index=False)
        secondary.to_csv(out/'SECONDARY_condition_comparisons.csv',index=False)
        pd.DataFrame(seed_rows).to_csv(out/'paired_seed_differences.csv',index=False)
        # Match each ablation to the corresponding main controller. Context-price comparisons
        # pair learning/frozen/noise-only AT THE SAME PRICE before attributing value to context.
        ablation=[]
        reference=main[(main.alpha==C['ablation_alpha'])&(main.epsilon==C['ablation_epsilon'])].set_index(['dataset','seed','method'])
        for key,g in frame[frame.suite.isin(['ablation','reward'])].groupby(['suite','dataset','method','context_fraction','feedback']):
            reference_method='gate_learned' if key[2].startswith('gate_') else 'learned'
            diffs=[row.common_mean_head_ap-reference.loc[(row.dataset,row.seed,reference_method),'common_mean_head_ap'] for _,row in g.iterrows()]
            ablation.append(dict(suite=key[0],dataset=key[1],method=key[2],context_fraction=key[3],feedback=key[4],reference=reference_method+'_main',**paired_stats(diffs)))
        price_rows=frame[(frame.alpha==C['ablation_alpha'])&(frame.epsilon==C['ablation_epsilon'])&
                         frame.method.isin(['learned','frozen','noise_only'])&frame.suite.isin(['main','ablation','context_price'])]
        for (dataset,price),g in price_rows.groupby(['dataset','context_fraction']):
            pivot=g.pivot(index='seed',columns='method',values='common_mean_head_ap')
            for other in ['frozen','noise_only']:
                if other not in pivot or 'learned' not in pivot:continue
                ablation.append(dict(suite='matched_context_price',dataset=dataset,method='learned',context_fraction=price,
                  feedback=C['feedback'],reference=other+'_same_price',**paired_stats((pivot.learned-pivot[other]).to_numpy())))
        if ablation:
            ablation=pd.DataFrame(ablation);ablation['holm_p_exploratory_family']=holm(ablation.sign_flip_p)
            ablation.to_csv(out/'EXPLORATORY_ablation_comparisons.csv',index=False)
    precision=[]
    for sd,n in itertools.product([.01,.02,.05],[5,10,20,30]):
        precision.append(dict(assumed_paired_SD=sd,n_seeds=n,approximate_95pct_t_half_width=float(stats.t.ppf(.975,n-1)*sd/math.sqrt(n)),
                              design_reference_only=True))
    pd.DataFrame(precision).to_csv(out/'precision_planning_reference.csv',index=False)
    write_json(out/'evidence_quality.json',dict(complete=complete,development=development,
       learning_timing_failures=[x['job_id'] for x in training if not x['learning_timing_pass']],
       no_claim_of_useful_learning_from_update_counts=True,release_dp_claim=False,
       seed_intervals_conditional_on_fixed_benchmarks=True,heads_are_not_independent_replicates=True,
       histogram_draws_are_not_training_replicates=True,previous_test_exposure=C['previous_test_exposure'],
       external_validation=False,protocol_local_not_independently_preregistered=True))
    (out/'INTERPRETATION.txt').write_text(
      'Development results are validation-only. Final evaluation is locked and uses committed final models.\n'
      'The primary contrast is learned versus frozen QUERY GATE, with allocation learning enabled in both.\n'
      'Each dataset estimate averages conditions within a seed before comparing independent simulation seeds.\n'
      'Sign-flip inference assumes exchangeability/symmetry under the paired null; t intervals assume approximately normal seed differences.\n'
      'Bootstrap intervals quantify seed variation and are not confidence intervals for external clinical populations.\n'
      'Holm adjustment covers the predeclared primary dataset family; secondary and exploratory families are labelled separately.\n'
      'An interval containing zero is inconclusive, not evidence of equivalence. Update counts do not establish a useful learned policy.\n'
      'Exact outputs and published seeded-noise experiments are NOT private releases. Clinical usefulness is not established.\n')
    make_plots(root,frame,training)


def make_plots(root,frame,training):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    out=root/'analysis_PUBLIC_ONLY'/'figures';out.mkdir(exist_ok=True)
    main=frame[frame.suite=='main']
    for dataset,g in main.groupby('dataset'):
        # Average conditions within seeds; plotted spread is between simulation seeds.
        means=g.groupby(['method','seed']).common_mean_head_ap.mean().reset_index()
        order=[m for m in C['main_methods'] if m in set(means.method)]
        fig,ax=plt.subplots(figsize=(10,4))
        for j,m in enumerate(order):
            values=means[means.method==m].common_mean_head_ap.to_numpy()
            ax.scatter(np.full(len(values),j),values,s=20,alpha=.65,color='steelblue')
            ax.plot([j-.2,j+.2],[values.mean()]*2,color='black',lw=2)
        ax.set_xticks(range(len(order)),order,rotation=35,ha='right');ax.set_ylabel('Common-set mean head AP')
        ax.set_title(dataset+' — each point is one seed averaged over conditions')
        fig.tight_layout();fig.savefig(out/(dataset+'_seed_AP.pdf'));plt.close(fig)
    for row in training:
        if row['method']!='gate_learned' or row['alpha']!=C['ablation_alpha'] or row['epsilon']!=C['ablation_epsilon'] or row['suite']!='main':continue
        folder=root/'runs'/row['job_id'];rounds=pd.read_csv(folder/'rounds.csv')
        decisions=pd.DataFrame(json.loads((folder/'decision_log_PUBLIC_ONLY.json').read_text()))
        fig,axes=plt.subplots(1,3,figsize=(12,3.2))
        axes[0].plot(rounds['round'],rounds.allocation_updates,label='Allocation');axes[0].plot(rounds['round'],rounds.gate_updates,label='Query gate')
        axes[0].set_ylabel('Training-time Q updates');axes[0].set_xlabel('Round');axes[0].legend()
        axes[1].plot(decisions.decision,decisions.queried_fresh_context.expanding().mean());axes[1].set_ylabel('Cumulative query rate');axes[1].set_xlabel('Decision')
        axes[2].plot(decisions.decision,decisions.q_loss,label='Allocation');axes[2].plot(decisions.decision,decisions.gate_loss,label='Gate')
        axes[2].set_ylabel('Latest replay loss');axes[2].set_xlabel('Decision');axes[2].legend()
        fig.tight_layout();fig.savefig(out/(row['job_id']+'_controller.pdf'));plt.close(fig)

# ----------------------------- execution controls -----------------------------
def verify_bundle(root,job,lock):
    folder=root/'bundles'/job['block_id'];stored=json.loads((folder/'bundle.json').read_text())
    if stored!=lock['bundles'][job['block_id']]:raise RuntimeError('Bundle metadata differs from locked manifest')
    if file_hash(folder/'training_validation.npz')!=stored['training_sha256']:raise RuntimeError('Training bundle changed')


def train_study(root,lock):
    jobs=lock['jobs'];protocol=lock['protocol_sha256'];selected=jobs[SHARD_INDEX::SHARD_COUNT]
    if (root/'EVALUATION_OPENED.json').exists():
        if any(not verify_complete(root/'runs'/j['job_id'],'TRAIN_COMPLETE.json',protocol) for j in jobs):
            raise RuntimeError('Test evaluation already opened. Retraining is prohibited in this study.')
    record_invocation(root,'train');loaded=None;last_block=None
    for ix,job in enumerate(selected):
        folder=root/'runs'/job['job_id']
        if verify_complete(folder,'TRAIN_COMPLETE.json',protocol):continue
        print(f"TRAIN {ix+1}/{len(selected)} {job['dataset']} seed={job['seed']} alpha={job['alpha']} eps={job['epsilon']} {job['method']} {job['suite']}",flush=True)
        verify_bundle(root,job,lock)
        if job['block_id']!=last_block:loaded=load_training(root,job);last_block=job['block_id']
        try:train_job(loaded,job,folder,protocol)
        except Exception:
            write_json(folder/'FAILURE.json',dict(job=job,error=traceback.format_exc(),excluded_from_analysis=False))
            raise # no silent exclusion or retry with a more favourable seed
    completed=sum(verify_complete(root/'runs'/j['job_id'],'TRAIN_COMPLETE.json',protocol) for j in jobs)
    print(f'Training complete: {completed}/{len(jobs)} planned jobs. Shard {SHARD_INDEX}/{SHARD_COUNT}.',flush=True)


def evaluation_gate(root,lock):
    """Called BEFORE opening ANY test arrays. Commit every planned final model."""
    protocol=lock['protocol_sha256'];models={};missing=[]
    for job in lock['jobs']:
        folder=root/'runs'/job['job_id']
        if not verify_complete(folder,'TRAIN_COMPLETE.json',protocol):missing.append(job['job_id'])
        else:models[job['job_id']]=file_hash(folder/'final_model.npz')
    if missing:raise RuntimeError(f'Test evaluation blocked: {len(missing)} planned models remain incomplete.')
    commit=dict(protocol_sha256=protocol,models=models,model_set_sha256=digest(models),
                holdout_membership_sha256={d:next(b['holdout_indices_sha256'] for b in lock['bundles'].values() if b['dataset']==d) for d in C['datasets']})
    path=root/'EVALUATION_OPENED.json'
    if path.exists():
        if json.loads(path.read_text())!=commit:raise RuntimeError('Committed model set changed after test evaluation opened')
    else:write_json(path,commit)
    return commit


def evaluate_study(root,lock,development=False):
    if not development:evaluation_gate(root,lock)
    record_invocation(root,'validation_development' if development else 'evaluate')
    for ix,job in enumerate(lock['jobs']):
        if not verify_complete(root/'runs'/job['job_id'],'EVAL_COMPLETE.json',lock['protocol_sha256']):
            print(f"EVALUATE {ix+1}/{len(lock['jobs'])} {job['method']} ({'validation' if development else 'held-out test'})",flush=True)
            verify_bundle(root,job,lock);evaluate_job(root,job,lock,development)
    write_json(root/'study_status.json',dict(status='development_evaluated' if development else 'test_evaluated',
                planned_runs=len(lock['jobs']),test_opened=not development))


def privacy_report(root,lock):
    private=[j for j in lock['jobs'] if method_config(j['method'])['private']]
    # Conservatively compose ALL runs for a record, even when datasets or held-out splits are disjoint.
    total=sum(eps_to_rho(j['epsilon']) for j in private)
    audit_cost=0.
    for j in private:
        if j['suite']=='main' and j['alpha']==C['ablation_alpha'] and j['epsilon']==C['ablation_epsilon']:
            audit_cost+=eps_to_rho(j['epsilon'])*C['evaluation_fraction']*len(C['audit_bins'])*sum(C['audit_multipliers'])*C['audit_repeats']
    write_json(root/'privacy_scope_PUBLIC_ONLY.json',dict(release_dp_claim=False,benchmark_noise=C['noise_mode']=='benchmark',
       exact_diagnostics_outside_guarantee=True,nonprivate_reference_present=any(j['method']=='non_private' for j in lock['jobs']),
       conditional_ideal_single_run_bound='rho=sum of context, clipping, gradient, protected feedback, and one protected local evaluation; epsilon=rho+2sqrt(rho log(1/delta))',
       adjacency='Replace one record at one fixed client and fixed split; fixed sizes, schemas and memberships.',
       hypothetical_conservative_all_run_rho=total,hypothetical_all_run_epsilon=rho_to_eps(total),delta=C['delta'],
       hypothetical_additional_histogram_audit_rho=audit_cost,
       warning='These are theoretical mechanism costs only. Full outputs contain exact data-derived diagnostics, nonprivate models and reproducible noise. They have no DP release guarantee. Data-dependent partition creation is also outside the conditional mechanism argument.'))


def package_results(root):
    root=root.resolve();target=root.parent/(root.name+'_PUBLIC_BENCHMARK_RESULTS.zip')
    files=[p for p in root.rglob('*') if p.is_file() and not p.name.endswith('.tmp')]
    write_json(root/'ARCHIVE_MANIFEST.json',dict(files={str(p.relative_to(root)):file_hash(p) for p in files if p.name!='ARCHIVE_MANIFEST.json'},public_benchmark_only=True))
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as z:
        for p in root.rglob('*'):
            if p.is_file() and not p.name.endswith('.tmp'):z.write(p,str(p.relative_to(root.parent)))
    print('RESULTS ZIP:',target,flush=True)
    if AUTO_DOWNLOAD:
        try:
            from google.colab import files
            files.download(str(target))
        except ImportError:
            try:
                from IPython.display import display,FileLink
                display(FileLink(str(target)))
            except ImportError:pass
    return target


def self_tests():
    """Fast invariant tests; real-data and exact-resume integration tests are separate."""
    checks=[]
    def check(name,condition):
        if not bool(condition):raise AssertionError(name)
        checks.append(name)
    for eps in [.5,8,16,32]:check('rho/epsilon inverse '+str(eps),abs(rho_to_eps(eps_to_rho(eps))-eps)<1e-10)
    for query in [True,False]:
        c=slot_costs(.1,.15,.75,True,True,query);check('budget balance '+str(query),abs(sum(c.values())-.1)<1e-12)
    fresh=slot_costs(.1,.15,.75,True,True,True);reuse=slot_costs(.1,.15,.75,True,True,False)
    check('saved context exclusively increases gradient',abs(reuse['gradient']-fresh['gradient']-.015)<1e-12 and reuse['feedback']==fresh['feedback'])
    ledger=Ledger(.1);ledger.spend('a',.1)
    try:ledger.spend('b',.01);raise AssertionError('Budget overspend accepted')
    except RuntimeError:checks.append('ledger rejects overspend')
    # Ties must be handled as one score threshold in AP and with half credit in AUC.
    y=np.array([0,1,0,1,1,0]);p=np.array([.2,.2,.8,.8,.8,.2]);h=np.zeros((2,10))
    np.add.at(h,(y,(p*10).astype(int)),1);m=histogram_metrics(h)
    check('histogram tied AP matches sklearn',abs(m['hist_ap']-average_precision_score(y,p))<1e-12)
    check('histogram tied AUC matches sklearn',abs(m['hist_auroc']-roc_auc_score(y,p))<1e-12)
    positive_hist=np.array([[0.,0.],[2.,3.]])
    check('all-positive histogram AP is defined but AUC is not',histogram_metrics(positive_hist)['hist_ap']==1. and histogram_metrics(positive_hist)['hist_auroc'] is None)
    check('no-positive AP explicitly undefined',exact_metrics(np.zeros(3,int),np.full(3,.2))['ap'] is None)
    rng=np.random.default_rng(981);X=rng.random((5,3));y=np.array([0,1,1,0,1]);layers=init_layers([3,4,3,1],rng)
    vector=flatten_layers(layers);analytic=clipped_mean_gradient(X,y,layers,1e12)
    finite=[]
    for j in range(len(vector)):
        plus=vector.copy();minus=vector.copy();plus[j]+=1e-6;minus[j]-=1e-6
        lp=per_example_backprop(X,y,assign_vector(plus,layers))[4].mean()
        lm=per_example_backprop(X,y,assign_vector(minus,layers))[4].mean()
        finite.append((lp-lm)/2e-6)
    check('focal gradient finite differences',np.max(abs(analytic-np.asarray(finite)))<2e-6)
    clip=.3;g=clipped_mean_gradient(X,y,layers,clip)
    X2=X.copy();y2=y.copy();X2[0]=0;y2[0]=1-y2[0]
    g2=clipped_mean_gradient(X2,y2,layers,clip)
    check('clipped mean replacement sensitivity example',np.linalg.norm(g-g2)<=2*clip/len(y)+1e-12)
    raw,_=context_values(X,y,layers,layers);raw2,_=context_values(X2,y2,layers,layers)
    check('bounded context sensitivity example',np.linalg.norm(raw-raw2)<=math.sqrt(5)/len(y)+1e-12)
    check('Holm known vector',np.allclose(holm([.01,.04,.03]),[.03,.06,.06]))
    ps=paired_stats(np.zeros(5));check('paired null includes ties',ps['sign_flip_p']==1 and ps['mean_difference']==0)
    for method in ['frozen','learned','gate_frozen','gate_learned','gate_no_recycle']:
        f=method_config(method);check('method flags '+method,f['learn_gate']==(method in ['gate_learned','gate_no_recycle']))
    gx=np.repeat(np.arange(120,dtype=float)[:,None],2,axis=0);gy=np.repeat(np.arange(120)%2,2)
    splits=profile_split(gx,gy,123);again=profile_split(gx,gy,123)
    check('profile split is reproducible',all(np.array_equal(a,b) for a,b in zip(splits,again)))
    check('duplicate profiles cannot cross splits',all(not set(gx[a,0])&set(gx[b,0]) for a,b in itertools.combinations(splits,2)))
    other=profile_split(gx,gy,987)
    check('fixed test records across training seeds',np.array_equal(splits[2],other[2]))
    check('training and validation differ across seeds',not np.array_equal(splits[0],other[0]))
    for value,expected in [('51 years 108 days',51+108/365.25),('87 years',87),('21.5',21.5),('0 years 1 day',1/365.25)]:
        check('age parser '+value,abs(parse_age(value)-expected)<1e-12)
    check('age missing stays missing',math.isnan(parse_age('--')) and math.isnan(parse_age(np.nan)))
    for value in ['unknown age','140 years','2 years 400 days','inf']:
        try:parse_age(value);raise AssertionError('Invalid age was accepted')
        except ValueError:checks.append('age rejects '+value)
    for method in ['gate_constant','gate_noise_only']:
        f=method_config(method);check('ablation trains both controllers '+method,f['learn_gate'] and f['learn_action'])
    observed,_=protect_context(np.arange(5)/5,'gate_constant',.1,50,BenchmarkNoise(7),np.random.default_rng(8))
    check('constant context removes raw coordinates',np.array_equal(observed,np.full(5,.5)))
    one,_=protect_context(np.zeros(5),'gate_noise_only',.1,50,BenchmarkNoise(7),np.random.default_rng(8))
    two,_=protect_context(np.ones(5),'gate_noise_only',.1,50,BenchmarkNoise(7),np.random.default_rng(8))
    check('noise-only context independent of raw values',np.array_equal(one,two))
    check('development plan includes every configured dataset',set(j['dataset'] for j in configurations(True))==set(C['datasets']))
    print('SELF-TESTS PASSED:',len(checks),flush=True)
    return dict(version=VERSION,checks=checks,count=len(checks),passed=True,environment=environment())


def main():
    validate_config()
    print(VERSION,'PHASE',PHASE,'PUBLIC BENCHMARK ONLY; no reviewer-score or utility guarantee.',flush=True)
    if PHASE=='selftest':self_tests();return
    if PHASE=='preflight':
        self_tests();dataset_preflight(STUDY_DIR/'dataset_checks');return
    if PHASE=='development':
        report=self_tests();root=DEVELOPMENT_DIR;lock=lock_study(root,True)
        write_json(root/'self_tests.json',report);train_study(root,lock)
        evaluate_study(root,lock,True);analyse(root,lock,True);privacy_report(root,lock);package_results(root)
        print('Inspect controller_learning_evidence.csv and validation results. Revise on development evidence, then lock a NEW final study.',flush=True)
        return
    root=STUDY_DIR
    if PHASE=='run':
        if SHARD_COUNT!=1:raise ValueError('Use separate train workers for sharding; run is sequential.')
        report=self_tests();lock=lock_study(root);write_json(root/'self_tests.json',report)
        train_study(root,lock);evaluate_study(root,lock);analyse(root,lock);privacy_report(root,lock);package_results(root)
        return
    if PHASE=='lock':
        report=self_tests();lock=lock_study(root);write_json(root/'self_tests.json',report);privacy_report(root,lock)
        print('Review and independently archive protocol_lock.json before training. Planned jobs:',len(lock['jobs']),flush=True)
        return
    if PHASE not in ['train','evaluate','analyse','package']:raise ValueError('Unknown phase: '+PHASE)
    lock=verify_lock(root)
    if PHASE=='train':train_study(root,lock)
    elif PHASE=='evaluate':evaluate_study(root,lock);analyse(root,lock);privacy_report(root,lock);package_results(root)
    elif PHASE=='analyse':record_invocation(root,'analyse');analyse(root,lock);privacy_report(root,lock)
    elif PHASE=='package':package_results(root)

if __name__=='__main__':main()
